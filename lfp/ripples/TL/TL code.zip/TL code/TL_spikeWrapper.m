function TL_spikeWrapper(basepath)

% INPUTS:
% [basepath] : string path to recording date (contains folders for each
% block on that date and an excel spreadsheet with recording info)

%% Read excel spreadsheet

if ~strcmp(basepath(end) , filesep)
    basepath = [basepath , filesep];
end
cd(basepath);

temp = dir(basepath);
fnames = {temp(~[temp.isdir]).name}';
clear temp;
temp = find(cell2mat(cellfun(@(z) ~isempty(strfind(z,'xls')),fnames,'uniformoutput',false)));
expath = [basepath  , fnames{temp}];
[~ , subjects] = xlsfinfo(expath)

for s = 1 : length(subjects)
    
    [~ , ~ , excel] = xlsread(expath , subjects{s});
    headers = [excel(1,:)];
    
    for r = 2:size(excel , 1)
        for h = 1 : length(headers)
            val = [];
            og = excel{r,h};
            if isnumeric(og) % is it nan
                val = og;
            else
                s2n = str2num(og);
                if ~isempty(s2n) % is it a number
                    val = s2n;
                else
                    sf = strfind(og , ',');
                    if ~isempty(sf) % is it strings separated by commas
                        sf = [0 , sf];
                        for ssf = 1 : length(sf)
                            if ssf < length(sf)
                                val{ssf} = og(sf(ssf)+1:sf(ssf+1)-1);
                            else
                                val{ssf} = og(sf(ssf)+1:end);
                            end
                        end
                    else
                        val = og;
                    end
                end
                
            end
            tempInfo{r-1,1}.(headers{h}) = val;
        end
    end
    
    % set up folders for saving data into
    sets = cell2mat(cellfun(@(z) z.set , tempInfo , 'uniformoutput' , false));
    [uSets i] = unique(sets);
    fs = strfind(basepath , filesep);
    dates = cellfun(@(z) z.date , [tempInfo(i)] , 'uniformoutput' , false);
    for d = 1 : length(dates)
        fol = [basepath(1:fs(end-2)) 'Subjects' , filesep , subjects{s} , filesep , num2str(dates{d})];
        if ~isfolder(fol)
            mkdir(fol);
        end
    end
    clear i fs dates d;
    
    %% Convert TDT 2 Dat for the current subject
    
    for us = 1 : length(uSets)
        ui = find(sets == uSets(us));
        
        % check if dat and expInfo files exists, if so ask user if he wants to use the
        % file
        % THIS DOES NOT WORK FOR MULTILE SETS NEEDS TO FIX IT...
        if exist([fol , filesep tempInfo{1}.store , '_' , num2str(tempInfo{1}.date) , '.dat']) == 2
            response = input('Would you like to load the current dat file (1/0)');
            if response == 1
%                 load([fol , filesep tempInfo{1}.store , '_' , num2str(tempInfo{1}.date) , '.dat']);
                 load([fol , filesep tempInfo{1}.store , '_expInfo.mat']);
            else
                expInfo{us} = TL_tdt2dat([tempInfo(ui)]);
            end
        else
             expInfo{us} = TL_tdt2dat([tempInfo(ui)]);
        end

        
        fsep = strfind(basepath , filesep);
        newpath = [basepath(1:fsep(end-2)) , 'Subjects' , filesep , expInfo{us}{1}.subject , filesep , num2str(expInfo{us}{1}.date) , filesep];
        clear fsep;
        
        % user needs to create XML file to continue:
        % 1. open dat in neuroscope and close it (XML file will be made)
        % 2. open XML file, go to spike groups and select channels per
        % tetrode group (0 indexed), set samples per waveform to 40, and
        % set # features to 3
        display('After making XML file and setting spike groups in ND Manager, press any key to continue');
        pause;
        
        % Run this function to make 'session' which includes experiment
        % information, but not really sure (legacy) .. it is needed for
        % some functions below I believe...
%         try
%         session = TL_CE_sessionTemplate(newpath, expInfo , 'viaGUI', false,...
%             'force', true, 'saveVar', true);
%         catch
%             display('Try making XML and spike groups again..you screwed up. Then press any key to continue');
%             pause;
%             session = TL_CE_sessionTemplate(newpath, expInfo , 'viaGUI', false,...
%             'force', true, 'saveVar', true);
%         end
%         basepath = session.general.basePath;
%         nchans = session.extracellular.nChannels;
%         fs = session.extracellular.sr;
%         spkgrp = session.extracellular.spikeGroups.channels;
%         [~, basename] = fileparts(basepath);
        
        %% Extract spike times with TL_spktimesWh
        fs = expInfo{us}{1}.fs;
        temp = expInfo{us}{1}.channels;
        temp(ismember(temp , expInfo{us}{1}.rmvch)) = nan;
        spkgrp = {[1:4],[5:8],[9:12],[13:16]};
        rmvch = expInfo{us}{1}.rmvch;
        spkgrp = cellfun(@(z) z(~ismember(z,rmvch)) , spkgrp , 'uniformoutput' , false);
        clear temp;
        nchans = length(expInfo{us}{1}.channels); % - length(expInfo{us}{1}.rmvch);
        [spktimes, ~] = TL_spktimesWh(expInfo{us} , 'basepath', newpath, 'fs', fs, 'nchans', nchans,...
            'spkgrp', spkgrp, 'saveVar', true, 'saveWh', true,...
            'graphics', true, 'force', true);
        
        % fix spkgrp to match spktimes2ns code (accomodate for removed
        % channels..)
        tot = 0;
        for s = 1 : length(spkgrp)
            sg{s} = [1:length(spkgrp{s})] + tot;
            tot = sg{s}(end);
        end
        TL_spktimes2ns('basepath' , newpath , 'fs' , fs ,...
            'nchans' , nchans , 'spkgrp', sg , 'mkClu' , true ,...
            'dur', dur , 't', t , 'psamp', [] , 'grps' , [1 : length(spkgrp)] ,...
            'spkFile' , 'temp_wh');
        
        % Extract EMG
        emgInfo = tempInfo;
        for e = 1 : length(tempInfo{us})
            emgInfo{e}.store = ['EMG' , tempInfo{e}.store(end)];
            emgInfo{e}.rmvch = [];
            emgInfo{e}.channels = 1:4;
        end
        TL_tdt2dat([emgInfo(ui)]);
    end
end
%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % session info (cell explorer foramt)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% session = CE_sessionTemplate(pwd, 'viaGUI', false,...
%     'force', true, 'saveVar', true);
% basepath = session.general.basePath;
% nchans = session.extracellular.nChannels;
% fs = session.extracellular.sr;
% spkgrp = session.extracellular.spikeGroups.channels;
% [~, basename] = fileparts(basepath);
%
% %
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % spike sorting
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % spike detection from temp_wh
%
%
% % spike rate
% for ii = 1 : length(spkgrp)
%     spktimes{ii} = spktimes{ii} / fs;
% end
% sr = firingRate(spktimes, 'basepath', basepath,...
%     'graphics', false, 'saveFig', false,...
%     'binsize', 60, 'saveVar', 'sr', 'smet', 'none',...
%     'winBL', [0 Inf]);
%
% % clip ns files
% % dur = -420;
% % t = [];
% % nsClip('dur', dur, 't', t, 'bkup', true, 'grp', [3 : 4]);
%
% create ns files
% dur = [];
% t = [];
% spktimes2ns('basepath', basepath, 'fs', fs,...
%     'nchans', nchans, 'spkgrp', spkgrp, 'mkClu', true,...
%     'dur', dur, 't', t, 'psamp', [], 'grps', [1 : length(spkgrp)],...
%     'spkFile', 'temp_wh');
%
% % clean clusters after sorting
% cleanCluByFet('basepath', pwd, 'manCur', false, 'grp', [1 : 4])
%
% % cut spk from dat and realign
% fixSpkAndRes('grp', 3, 'dt', 0, 'stdFactor', 0);
%
% % cell explorer metrics
% cell_metrics = ProcessCellMetrics('session', session,...
%     'manualAdjustMonoSyn', false, 'summaryFigures', false,...
%     'debugMode', true, 'transferFilesFromClusterpath', false,...
%     'submitToDatabase', false, 'getWaveformsFromDat', true);
% cell_metrics = CellExplorer('basepath', basepath);
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % spikes
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% % cluster validation
% mu = [];
% spikes = cluVal('spikes', spikes, 'basepath', basepath, 'saveVar', true,...
%     'saveFig', false, 'force', true, 'mu', mu, 'graphics', false,...
%     'vis', 'on', 'spkgrp', spkgrp);
%
% % firing rate
% binsize = 60;
% winBL = [1 Inf];
% fr = firingRate(spikes.times, 'basepath', basepath, 'graphics', false, 'saveFig', false,...
%     'binsize', binsize, 'saveVar', true, 'smet', 'MA', 'winBL', winBL);
%
% % CCG
% binSize = 0.001; dur = 0.12; % low res
% binSize = 0.0001; dur = 0.02; % high res
% [ccg, t] = CCG({xx.times{:}}, [], 'duration', dur, 'binSize', binSize);
% u = 20;
% plotCCG('ccg', ccg(:, u, u), 't', t, 'basepath', basepath,...
%     'saveFig', false, 'c', {'k'}, 'u', spikes.UID(u));
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % lfp
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % create lfp
% LFPfromDat('basepath', basepath, 'cf', 450, 'chunksize', 5e6,...
%     'nchans', nchans, 'fsOut', 1250,...
%     'fsIn', fs)
%
% % load lfp
% lfpInterval = [150 * 60, 180 * 60];
% lfp = getLFP('basepath', basepath, 'ch', [spkgrp{:}], 'chavg', {},...
%     'fs', 1250, 'interval', lfpInterval, 'extension', 'lfp',...
%     'savevar', true, 'forceL', true, 'basename', '');
%
% % remove 50 Hz from signal
% emgOrig = filterLFP(emgOrig, 'fs', 1250, 'stopband', [49 51],...
%     'dataOnly', true, 'saveVar', false, 'graphics', false);
%
% acc = EMGfromACC('basepath', basepath, 'fname', [basename, '.lfp'],...
%     'nchans', 20, 'ch', [17 : 19], 'saveVar', true, 'fsIn', 1250,...
%     'graphics', false);
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % sleep states
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% % prep signal (alt 2)
% [EMG, EEG, sigInfo] = as_prepSig([basename, '.lfp'], acc.mag,...
%     'eegCh', [9 : 12], 'emgCh', [], 'saveVar', true, 'emgNchans', [],...
%     'inspectSig', true, 'forceLoad', true, 'eegFs', 1250, 'emgFs', 1250);
%
% % manually create labels
% labelsmanfile = [basename, '.AccuSleep_labelsMan.mat'];
% AccuSleep_viewer(EEG, EMG, 1250, 1, [], labelsmanfile)
%
% % classify with a network
% ss = as_wrapper(EEG, EMG, [], 'basepath', basepath, 'calfile', [],...
%     'viaGui', false, 'forceCalibrate', true, 'inspectLabels', true,...
%     'saveVar', true, 'forceAnalyze', true, 'fs', 1250);
%
% % inspect separation after manual scoring
% as_inspectSeparation(EEG, EMG, labels)
%
% % get confusion matrix between two labels
% [ss.netPrecision, ss.netRecall] = as_cm(labels1, labels2);
%
% % show only x hours of data
% x = 11;
% tidx = [1 : x * 60 * 60 * 1250];
% lidx = [1 : x * 60 * 60];
% AccuSleep_viewer(EEG(tidx), EMG(tidx), 1250, 1, labels(lidx), [])
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % handle dat  files
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% %%% cat dat
% nchans = 17;
% fs = 1250;
% newpath = mousepath;
% datFiles{1} = 'K:\Data\lh91\experiment11\recording1\continuous\Rhythm_FPGA-109.0\continuous.dat';
% datFiles{2} = 'K:\Data\lh91\experiment11\recording1\continuous\Rhythm_FPGA-109.0\28e1.dat';
% sigInfo = dir(datFiles{1});
% nsamps = floor(sigInfo.bytes / class2bytes('int16') / nchans);
% parts{1} = [nsamps - 2 * 60 * 60 * fs nsamps];
% parts{2} = [0 4 * 60 * 60 * fs];
%
% catDatMemmap('datFiles', datFiles, 'newpath', newpath, 'parts', parts,...
%     'nchans', nchans, 'saveVar', true)
%
%
% % preproc dat
% clip = [1, 864000000];
% datInfo = preprocDat('basepath', pwd,...
%     'fname', 'continuous.dat', 'mapch', 1 : 20,...
%     'rmvch', [3, 7, 13], 'nchans', 20, 'saveVar', false, 'clip', clip,...
%     'chunksize', 5e6, 'precision', 'int16', 'bkup', true);
%
%
