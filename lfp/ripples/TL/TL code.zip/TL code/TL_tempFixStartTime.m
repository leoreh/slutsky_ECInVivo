function TL_tempFixStartTime(pathname)

%Go thru each exp info in directory and convert startTime/stopTime of each
%block/set to the original file information from tev. 

temp = dir(pathname);
folnames = {temp([temp.isdir]).name};
i = cell2mat(cellfun(@(z) ~strcmp(z(1),'.') , folnames , 'uniformoutput' , false));
folnames = {folnames(i)};
clear temp;
