function [crossings, sptimes2000 , rawClip , filtClip , logTDT] = quickRipSpikes(rawTrace , rippleSampleIndex)

% description:
% loops through each ripple and finds the multiunit spike times during the
% pre-ripple and the ripple period. Refined for single electrode
 
% -------------------------------------

% some variable descriptions (more below)
% [rippleSampleIndex] : sample index for the start (column 1) and end
% (column 2) of each ripple. # rows = # ripples.
% [rawTrace] is the raw (unfiltered) voltage trace from the channel should be sampled at least 20,000 but probably will work ~12500.
% [baselineNumSamps] is the number of samples to include for 'baseline'
% before each ripple (recommend ~25-50 miliseconds worth of samples) and
% for after

% -------------------------------------

% OUTPUTS:
% [crossings] and [sptimes2000] which shows the sample indices and
% spike times in ms,respectively, normalized to the onset of each ripple's
% baseline period (baselineNumSamps)
% [rawClip] : rawClip of the trace of each current ripple (r) from
% -baselineNumSamps to length ripple + baselineNumSamps
% [filtClip] : bessefiltered trace for each ripple that will be used for spike detection
% [logTDT] : logical index for each ripple showing which samples
% are in the ripple (1) and which are in the baseline or postripple
% period (helpful for plotting the ripples and showing as 2 colors)

% -------------------------------------------

% User enters sampling Rate here !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

if size(rawTrace , 2) == 1
    rawTrace = rawTrace';
end

sampRate = [12500]; % hz
shadowSamps = floor(sampRate * 0.66/1000);% (0.66 ms of samples)
baselineNumSamps = floor(sampRate*25/1000); %25 ms of baseline

% filter full trace in bins
binz = [0:45000000:length(rawTrace)];
% binz = [0:45000000:length(rawTrace)];
if binz(end) ~= length(rawTrace)
    binz(end+1) = length(rawTrace);
end

% [filtTrace] : rawTrace bandpass filtered for spike detection
filtTrace = [];
for b = 1 : length(binz) - 1
    filtTrace = [filtTrace , besselfilter(4 , 300 , 6000 , 12500 , rawTrace(binz(b)+1:binz(b+1)))];
end
thresh = -3 * std(filtTrace);

% -----------------------------------------

for r = 1 : size(rippleSampleIndex , 1)
    
    % [rawClip] : rawClip of the trace of the current ripple (r) from
    % -baselineNumSamps to length ripple + baselineNumSamps
    rawClip{r,1} = double(rawTrace([rippleSampleIndex(r,1) - baselineNumSamps :rippleSampleIndex(r,2) + baselineNumSamps]));
    
%     % [filtClip] : bessefiltered trace clipped that will be used for spike detection
    filtClip{r,1} = double(filtTrace([rippleSampleIndex(r,1) - baselineNumSamps :rippleSampleIndex(r,2) + baselineNumSamps]));
    
    % [logTDT] : logical index for each ripple showing which samples
    % are in the ripple (1) and which are in the baseline or postripple
    % period (helpful for plotting the ripples and showing as 2 colors)
    temp = zeros(length(rawClip) , 1);
    temp(baselineNumSamps + 1 : end - baselineNumSamps) = 1;
    logTDT{r,1} = logical(temp); % logical index for each
    clear bf c temp;
    
    % [currentCrossings] is the sample number for each threshold crossing for the
    % current ripple (r), normalized to the onset of its baseline period
    currentCrossings = find((filtClip{r,1}(1:end-1) > thresh) &  filtClip{r,1}(2:end) <= thresh)';  % ad
    currentCrossings = sort(currentCrossings);
    % remove  shadow period violations
    currentCrossings( 1 + find( diff(currentCrossings) <= shadowSamps ) ) = [];
    
    % [crossings] : currentCrossings for each ripple into cell array
    crossings{r,1} = currentCrossings;
     
    % [sptimes2000] is the spike times normalized to the onset of the
    % current ripple
    sptimes2000{r,1} = 1000*currentCrossings/sampRate;
    clear currentCrossings;
end
end