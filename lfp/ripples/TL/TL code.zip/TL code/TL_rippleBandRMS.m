function [beztRipChans] = TL_rippleBandRMS(pathname , saveRMS)

%% Find which recordings are baseline

if ~strcmp(pathname(end) , filesep)
    pathname = [pathname , filesep];
end

% Find recording folders;
% [recFols] : cell array of recording folders
d = dir(pathname);
d = {d([d.isdir]).name};
i = cell2mat(cellfun(@(z) ~strcmp(z(1) , '.') , d , 'uniformoutput' , false));
recFols = [d(i)];
clear d i;

bL = nan(length(recFols) , 1);
for r = 1 : length(recFols)
    
    recPath = [pathname , recFols{r} , filesep];
    
    % Load excel file with experiment info
    d = dir(recPath);
    fnames = {d(~[d.isdir]).name}';
    clear d;
    temp = find(cell2mat(cellfun(@(z) ~isempty(strfind(z,'xls')) , fnames , 'uniformoutput' , false)));
    [~ , ~ , exc{r}] = xlsread([recPath , fnames{temp}]); %%%%%%%%%%%%%%%%%%%
    clear temp;
    
    bL(r) = exc{r}{2 , find(strcmp([exc{r}(1,:)] , 'Baseline'))};
    
end

baselineFols = [recFols(logical(bL))]; %%%%%%%%%%%%%%%%%%%%%%
exc = [exc(logical(bL))];
clear bL recFols;

%% Calculate rms from each channel across 6 hour epochs during baseline, and find the best

RMS = [];

for b = 1 : length(baselineFols)
    currentPath = [pathname , baselineFols{b} , filesep];
    
    % Check directory in pathname ---------------------------------------------
    % [fname] : names of files in pathname, including their suffix (eg .mat ,.xls)
    temp = dir(currentPath);
    filenames = {temp(~[temp.isdir]).name}';
    clear temp;
    
    % Load sleep states and convert to conformity
    sleep = TL_extractSleep(currentPath)
    
    % Load tempel spreadsheet with experiment and analysis parameters and
    % extract info ------------------------------------------------------------
    xCurr = exc{b};
    headers = [xCurr(1,:)];
    
    % a = xl{2 , find(strcmp(headers , 'chunkHr'))};
    b = xCurr{2 , find(strcmp(headers , 'startHr'))};
    c = xCurr{2 , find(strcmp(headers , 'stopHr'))};
    
    % automatically use 6 hour bins
    ranges = b:6:c;
    if ranges(end) ~= c
        ranges = [ranges , c];
    end
    ranges = ranges*60*60;
    clear b c;
    
    t = xCurr{2 , find(strcmp(headers , 'tetrodes'))};
    col = strfind(t,':');
    semi = strfind(t,';');
    ch = [];
    tet = [];
    for cc = 1 : length(col)
        vals = [str2num(t(semi(cc)+1:col(cc)-1)) : str2num(t(col(cc)+1:semi(cc+1)-1))]';
        ch = [ch ; vals];
        tet = [tet ; col*ones(length(vals) , 1)];
    end
    clear cc t col semi;
    
    for r = 1 : length(ranges) - 1
        r=4;
        currRow = size(RMS , 1) + 1;
        for c = 1 : length(ch)
            lfp = TL_getLFP('basepath' , currentPath , 'ch' , ch(c) , 'fs' , 1250 , ...
                'extension' , 'lfp' , 'savevar' , true , 'forceL' , true , 'interval' , [ranges(r) , ranges(r+1)]);
            
            % Run butterworth Filter
            [c1 c2] = butter(5,[100 250]/(1250/2),'bandpass');
            filtD = filtfilt(c1,c2,double(lfp.data));
            
            % Extract Only NREM states from the filtered Data
            % this is not exactly current because of the concatenations
            % between different NREM states but all channels should have
            % the same number of concatenations at least
            rEnd = ranges(r+1);
            if r == length(ranges) - 1 & rEnd > length(sleep)
                rEnd = length(sleep) - 1;
            end
            currSleep = sleep([ranges(r) :  rEnd] + 1);
            currSleep = currSleep == 4;
            currSleep = repelem(currSleep , 1250);
            if length(currSleep) > length(lfp.data)
            currSleep = currSleep(1:length(lfp.data));
            end
            d = find(diff(currSleep) == 1) + 1;
            if currSleep(1) == 1
                d = [1 ; d];
            end
            dd = find(diff(currSleep) == - 1) - 1;
            if currSleep(end) == 1
                dd = [dd ; length(currSleep)];
            end
            epochs = [d , dd];
            clear d dd;
            tempRMS = [];
            for e = 1 : size(epochs , 1)
                tempRMS = [tempRMS , repelem(rms(filtD(epochs(e,1):epochs(e,2))) , diff(epochs(e,:)))];
            end
            RMS(currRow,c) = mean(tempRMS); %rms(filtD(logical(currSleep)));
            clear tempRMS;
        end
        %%
    end
end

% Now find the best channel
[~ , bezt] = sort(mean(RMS,1),'descend');
beztRipChans.RMS = RMS;
beztRipChans.rank = bezt;
beztRipChans.tet = tet;

if saveRMS
    savePath = save([pathname , 'beztRipChans'],'beztRipChans');
end