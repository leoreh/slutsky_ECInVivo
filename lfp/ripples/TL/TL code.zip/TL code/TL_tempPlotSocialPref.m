function TL_tempPlotSocialPref(data2)


F = figure('units' , 'inches' , 'position' , [1 0.5  12 3] , 'visible' , 'on');
set( F, 'Renderer' , 'opengl');
ax.soc = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 0.5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XLim' , [0.75 5] , 'XTick' , [1:5]);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;
ax.soc.YLabel.String = 'Social Interaction Time (s)';
ax.soc.XLabel.String = 'Minute';

ax.empty = axes('parent' ,  F , 'units' , 'inches' , 'position' , [2.5 0.5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XLim' , [0.75 5] , 'XTick' , [1:5]);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;
ax.empty.YLabel.String = 'Empty Interaction Time (s)';
ax.empty.XLabel.String = 'Minute';

ax.pref = axes('parent' ,  F , 'units' , 'inches' , 'position' , [4.5 0.5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XLim' , [0.75 5] , 'XTick' , [1:5] , 'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1.0]);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;
ax.pref.YLabel.String = 'Social Preference';
ax.pref.XLabel.String = 'Minute';

ax.meanSoc = axes('parent' , F , 'units' , 'inches' , 'position' , [6.5 0.5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XLim' , [0.25 2.5] , 'XTick' , []);
hold on;
ax.meanSoc.YLabel.String = 'Social Interaction Time (s/min)';

ax.meanEmpty = axes('parent' , F , 'units' , 'inches' , 'position' , [8 0.5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XLim' , [0.25 2.5] , 'XTick' , []);
hold on;
ax.meanEmpty.YLabel.String = 'Empty Interaction Time (s/min)';

ax.meanPref = axes('parent' , F , 'units' , 'inches' , 'position' , [9.5 0.5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XLim' , [0.25 2.5] , 'XTick' , []);
hold on;
ax.meanPref.YLabel.String = 'Social Preference';

cols = {[0.2 0.2 0.2] , 'c'};
ug = unique(data2.gen);

pref = data2.soc ./ (data2.soc + data2.empty);

for u = 1 : length(ug)
    i = data2.gen == ug(u);
    
    plot(ax.soc , repmat([1:5]',1,sum(i)) , data2.soc(i,:)' , 'linestyle' , '-' , 'color' , cols{u} , ...
        'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , cols{u} , 'markeredgecolor' , cols{u} , 'linewidth' , 0.75);

        plot(ax.empty , repmat([1:5]',1,sum(i)) , data2.empty(i,:)' , 'linestyle' , '-' , 'color' , cols{u} , ...
        'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , cols{u} , 'markeredgecolor' , cols{u} , 'linewidth' , 0.75);
    
            plot(ax.pref , repmat([1:5]',1,sum(i)) , pref(i,:)' , 'linestyle' , '-' , 'color' , cols{u} , ...
        'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , cols{u} , 'markeredgecolor' , cols{u} , 'linewidth' , 0.75);
    
    jit = (rand(sum(i),1) - 0.5)/2
    bar(ax.meanSoc , u , mean(mean(data2.soc(i,:),2)) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.25);
plot(ax.meanSoc , u*ones(sum(i),1) + jit , mean(data2.soc(i,:),2) , 'linestyle' , 'none' , 'marker', 'o' , 'markersize' , 5 , 'markeredgecolor' , cols{u} , ...
    'markerfacecolor' , 'none');
    
     
    bar(ax.meanEmpty , u , mean(mean(data2.empty(i,:),2)) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.25);
plot(ax.meanEmpty , u*ones(sum(i),1) + jit , mean(data2.empty(i,:),2) , 'linestyle' , 'none' , 'marker', 'o' , 'markersize' , 5 , 'markeredgecolor' , cols{u} , ...
    'markerfacecolor' , 'none');

bar(ax.meanPref , u , mean(mean(pref(i,:),2)) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.25);
plot(ax.meanPref , u*ones(sum(i),1) + jit , mean(pref(i,:),2) , 'linestyle' , 'none' , 'marker', 'o' , 'markersize' , 5 , 'markeredgecolor' , cols{u} , ...
    'markerfacecolor' , 'none');
end