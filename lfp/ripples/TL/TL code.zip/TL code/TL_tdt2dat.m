function [expInfo] = TL_tdt2dat(expInfo)

% converts tank (TDT) to dat (neurosuite). Concatenates blocks.
% performs basic preprocessing. if data (second output) is requested than
% will output a matrix of data instead of a .dat file
%
% INPUT:
%   basepath    path to recording folder {pwd}.
%   store       stream. typically {'Raw1'} or 'Raw2'
%   blocks      vector. blocks to convert {all}. e.g. [1 2 4 5];
%   chunkSec   load data in chunks {60} s. if empty will load entire block.
%   mapch       new order of channels {[]}.
%   rmvch       channels to remove (according to original order) {[]}
%   clip        array of mats indicating times to diregard from recording.
%               each cell corresponds to a block. for example:
%               clip{3} = [0 50; 700 Inf] will remove the first 50 s from
%               block-3 and the time between 700 s and the end of Block-3
%   saveVar     logical. save variable {true} or not (false).
%
% OUTPUT
%   info        struct with fields describing tdt params
%   data        mat (channels x samples). only if requested
%
% CALLS:
%   TDTbin2mat
%   natsort
%
% TO DO LIST:
%   handle chunks better (e.g. linspace)
%   add time limit to split files
%   separate chunks to standalone function (see n2chunks, not implemented)
%   include clip within blockduration
%
% 06 dec 18 LH      updates:
% 18 sep 19 LH      handle arguments
% 27 mar 20 LH      allow output mat instead of dat file
% 04 sep 20 LH      added nsamps

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% arguments
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;

% if isempty(clip)
%     clip{max(blocks)} = [];
% else
%     if length(clip) < max(blocks)
%         clip{max(blocks)} = [];
%     elseif length(clip) > max(blocks)
%         error('clip array larger then number of blocks')
%     end
% end

%% set some vars
scalef = 1e6;   % scale factor for int16 conversion [uV]
chunkSec = 300;
nblocks = length(expInfo);
blocknames = cellfun(@(z) z.blockName , expInfo , 'uniformoutput' , false);
% store = 'Raw2';
nsec = zeros(1, nblocks);
nsamps = zeros(1, nblocks);
data = [];

%%
for e = 1 : length(expInfo)
    store = expInfo{e}.store;
    % open dat file
    if e == 1
        bp = expInfo{e}.basepath
         fs = strfind(bp , filesep);
         newname = [bp(1:fs(end-2)) , 'Subjects' , filesep , expInfo{e}.subject , filesep , num2str(expInfo{e}.date) , filesep , store , '_' , num2str(expInfo{e}.date) , '.dat'];
%         newname = [expInfo{e}.basepath , blocknames{e} , filesep , blocknames{e} , '.dat'];
    end
    if nargout == 1
        fout = fopen(newname, 'w');
        if(fout == -1)
            error('cannot open file');
        end
    end

% rearrange channels according to rmvch
mapch = expInfo{e}.channels;
rmvch = expInfo{e}.rmvch;
mapch = mapch(~ismember(mapch, rmvch));
    nch = length(mapch);
    if sum(mapch > nch)
        mat = [unique(mapch); (1 : nch)]';
        for j = 1 : nch
            mapch(j) = mat(mat(:, 1) == mapch(j), 2);
        end
    end
    
    blockpath = [expInfo{e}.basepath , filesep , blocknames{e}];
    fprintf(1, 'Working on %s\n', blocknames{e});
    
    heads = TDTbin2mat(blockpath, 'TYPE', {'streams'}, 'STORE', store, 'HEADERS', 1);
    nsec(e) = heads.stores.(store).ts(end);
    
    if isempty(chunkSec)       % load entire block
        nchunks = 1;
        chunks = [0 0];
    else                        % load block in chunks
        nchunks = ceil(nsec(e) / chunkSec);
        chunks = [0 : chunkSec : chunkSec * (nchunks - 1);...
            chunkSec : chunkSec : chunkSec * nchunks]';
        chunks(nchunks, 2) = 0;
        chunks(1, 1) = 0;
    end
    
    
    % clip unwanted times
    clipblk = expInfo{e}.excludeS;
    if ~isnan(clipblk)
        if isempty(chunkSec)
            if size(clipblk, 1) == 1 && clipblk(1) == 0
                chunks(1, 1) = clipblk(1, 2);
            elseif size(clipblk, 1) == 1 && clipblk(2) == Inf
                chunks(1, 2) = clipblk(1, 1);
            else
                for j = 1 : size(clipblk, 1) - 1
                    chunks = [chunks; clipblk(j, 2) clipblk(j + 1, 1)];
                end
            end
            if clipblk(1, 1) > 0
                chunks = [0 clipblk(1, 1); chunks];
            end
        else
            idx = zeros(1, 2);
            for j = 1 : size(clipblk, 1)
                idx(1) = find(chunks(:, 2) > clipblk(j, 1), 1, 'first');
                chunks(idx(1), 2) = clipblk(j, 1);
                if clipblk(j, 2) ~= Inf
                    idx(2) = find(chunks(:, 1) > clipblk(j, 2), 1, 'first');
                    chunks(idx(2), 1) = clipblk(j, 2);
                    rmblk = idx(1) + 1 : idx(2) - 1;
                else
                    rmblk = idx(1) + 1 : size(chunks, 1);
                end
                if ~isempty(rmblk)
                    chunks(rmblk, :) = [];
                end
            end
        end
        chunks = chunks(any(chunks, 2), :);
        nchunks = size(chunks, 1);
    end
    
    for j = 1 : nchunks
        dat = TDTbin2mat(blockpath, 'TYPE', {'streams'}, 'STORE', store,...
            'T1', chunks(j , 1) , 'T2' ,chunks(j , 2) );
        datI = dat.info;
        dat = dat.streams.(store).data;
        
        if ~isempty(dat)
            if ~isnan(rmvch)                     % remove channels
                dat(rmvch, :) = [];
            end
            
            if ~isempty(mapch)                     % remap channels
                dat = dat(mapch, :);
            end
            
            if nargout == 1
                fwrite(fout, dat(:), 'int16');     % write data
            elseif nargout == 2
                data = [data, dat];                % output data
            end
        end
        nsamps(e) = [nsamps(e) + size(dat, 2)];
    end
    
    expInfo{e}.blockduration = nsec;
    expInfo{e}.fs = heads.stores.(store).fs;
    expInfo{e}.nsamps = nsamps;
    expInfo{e}.nsec = nsec;
    expInfo{e}.startTime = datI.utcStartTime;
    expInfo{e}.stopTime = datI.utcStopTime;
    expInfo{e}.duration = datI.duration
    expInfo{e}.channels = mapch;
    if nargout == 1
        rc = fclose(fout);
        if rc == -1
            error('cannot save new file');
        end
        datInfo = dir(newname);
        fprintf(1, '\nCreated %s. \nFile size = %.2f MB\n', newname, datInfo.bytes / 1e6);
    end
    fprintf(1, '\nElapsed time = %.2f seconds\n', toc)
    
    % create lfp file
    if contains(store, 'Raw')
        TL_LFPfromDat(expInfo{e} , 'basepath', [expInfo{e}.basepath , blocknames{e}] , 'cf', 450, 'chunksize', 5e6,...
            'nchans', length(mapch), 'fsOut', 1250,...
            'fsIn', heads.stores.(store).fs)
    end
    
    % save expInfo
    fs = strfind(newname , filesep);
    save([newname(1:(fs(end))) , expInfo{e}.store '_expInfo.mat'] , 'expInfo');
end

% EOF