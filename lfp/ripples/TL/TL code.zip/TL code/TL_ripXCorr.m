function [xc] = TL_ripXCorr(cat ,  recNum , timeRange , stateChoice)

% Cross correlate units during ripples and nonripples within the recording
% number, timerange (hrs), and state value that the user inputs. Only cross
% correlate units recorded on the same tetrode

%% Extract ripples, mua, sua, states within user-inputted range
% [xDist] : width in seconds of the user-inputted time range
xDist = 60*60*(timeRange(2) - timeRange(1));

% [startSec] : start time in seconds of the user inputted time range
% relative to beginning of cat
% [stopSec] : stop time in seconds of the user inptuted time range relative
% to beginning of cat
startSec  = 60 * 60 * (24 - cat.expInfo{1}.RecStartTime + (recNum - 1 - 1)*24 + timeRange(1));
stopSec = startSec + xDist;

% Extract single-unit activity
% need to include nans in the state due to gaps between recordings...
% [spt] : cell array of individual units within the user-inputted time
% range and their spike times in seconds normalized to onset of the time
% range.
temp = cellfun(@(z) z(z>=startSec & z<stopSec) - startSec , cat.su.spt , 'uniformoutput' , false);
indx = cell2mat(cellfun(@(z) ~isempty(z) , temp , 'uniformoutput' , false));
su.spt = temp(indx);
su.tet = cat.su.tet(indx);
su.clusID = cat.su.clusID(indx);
clear temp indx;

% Extract statez
% [state] : state for each second within the time range
indx = floor(cat.state.sec) >= startSec & cat.state.sec < stopSec;
state = cat.state.val(indx);
clear indx;

% Extract ripplez
% [pS] : peak times in seconds for each ripple normalized to onset of the
% time range
% [rS] : range times in seconds for each ripple normalized to onset of the
% time range
% [d] : duration in ms for each included ripple
keep = cat.ripples.rangeSec(:,1) >= startSec & cat.ripples.rangeSec(:,2) < stopSec;
pS = cat.ripples.peakSec(keep,:) - startSec;
rS = cat.ripples.rangeSec(keep,:) - startSec;
d = cat.ripples.durationMs(keep);
if ~isempty(stateChoice)
    keep = state(floor(pS) + 1) == stateChoice;
    pS = pS(keep);
    rS = rS(keep,:);
    d = d(keep);
end
clear keep;

%% Extract single unit spike times during all for analysis

spt = su.spt;
ripSpkSec = cell(length(spt),1);
nonripSpkSec = spt;
for s = 1 : length(spt)
    for r = 1 : size(rS , 1)
        % need to make logical index marking ripple spikes so they can be
        % eliminated from spt for nonripple spike correlations.
        i = spt{s} >= rS(r,1) & spt{s} < rS(r,2);
        ripSpkSec{s} = [ripSpkSec{s} ; spt{s}(i)];
        nonripSpkSec{s}(i) = nan;
    end
    nonripSpkSec{s} = 1000 * nonripSpkSec{s}(~isnan(nonripSpkSec{s}));
end
clear spt;
%% Now loop thru all combinations, store unit numbers and histograms

% Find combinations
uT = unique(su.tet);
combos = [];
for t = 1 : length(uT)
    combos = [combos; combntns(su.clusID(su.tet == uT(t)),2)];
end

for c = 1 : size(combos , 1)
    % convert spiketimes to bins
    b1 = histcounts(ripSpkSec{combos(c,1)},[0:0.5/1000:diff(timeRange)*60*60]);
    b2 = histcounts(ripSpkSec{combos(c,2)},[0:0.5/1000:diff(timeRange)*60*60]);

    xc.rip{c,1} = xcorr(b1,b2,20)/sqrt(sum(abs(b1).^2)*sum(abs(b2).^2));
    
        b1 = histcounts(nonripSpkSec{combos(c,1)},[0:0.5/1000:diff(timeRange)*60*60]);
    b2 = histcounts(nonripSpkSec{combos(c,2)},[0:0.5/1000:diff(timeRange)*60*60]);
    xc.nonrip{c,1} = xcorr(b1,b2,20)/sqrt(sum(abs(b1).^2)*sum(abs(b2).^2));
%     temp = xcorr(ripSpkSec{combos(c,1)} , ripSpkSec{combos(c,2)} , 'coeff' , 30/1000);
end
% % Run cross correlation (probability normalized to spike count of 1st unit)
% for c = 1 : size(combos , 1)
%     xc.rip{c} = pxcorr(ripSpkSec{combos(c,1)} , ripSpkSec{combos(c,2)} , 500 , 30/1000);
%     xc.nonrip{c} = pxcorr(nonripSpkSec{combos(c,1)} , nonripSpkSec{combos(c,2)} , 500 , 30/1000);
% end
xc.clusID = combos;
xc.state = stateChoice;
xc.timeRange = timeRange;
xc.recNum = recNum;




end













