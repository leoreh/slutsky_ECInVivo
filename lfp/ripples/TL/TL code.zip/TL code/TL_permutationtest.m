function [P histo] = TL_permutationtest(group1 , group2)

% Inputs:
% [group1] = data for first group 
% [group2] = data for second group ""
% [varargin] = 1st varargin is figure title as string, 2nd is position on
% screen (eg1st two vals of position vector)

% Outputs:
% [P] = p-value

% -------------------------------------------------------------------------

if size(group1,2)>1
    group1 = group1';
end
if size(group2,2)>1
    group2 = group2';
end

%Concatenates both groups to draw random subpopulations
group_cat = cat(1,group1,group2);

group1_size = size(group1,1);
group2_size = size(group2,1);
cat_size = group1_size + group2_size;
true_diff = abs(mean(group1) - mean(group2));
for rep = 1:100000
    
    %Includes correction so that group1_perm and group2_perm are mutually
    %exclusive
    all_perm = randperm(cat_size , cat_size);
    group1_perm = all_perm(1:group1_size);
    group2_perm = all_perm(group1_size+1:end);
    
    group1perm_mean = mean(group_cat(group1_perm));
    group2perm_mean = mean(group_cat(group2_perm));
    
    null_diff(rep) = abs(group1perm_mean - group2perm_mean);
     
end
% Calculate p-value
P = sum(null_diff>=true_diff)/length(null_diff);
% if true_diff<0
%     P = 1 - sum(null_diff>true_diff)/length(null_diff);
% else if true_diff>=0
%         P = 1 - sum(null_diff<true_diff)/length(null_diff);
%     end
% end
% 
% P = 2*P;

% Create histogram of shuffled differences, with the true difference marked

pos = [0.5 0.5 1.5 1.5];

histo = figure('visible' , 'on' , 'units' , 'inches' , 'Position' , pos , 'PaperUnits' , 'inches' , 'PaperPosition' , [1 1 4 4] , 'toolbar' , 'none' );

histo_plot = histogram(null_diff , 'edgecolor' , 'none' , 'facecolor' ,'k' , 'facealpha' , 1 , 'normalization' , 'probability');
ax=gca;
set(gca , 'box' , 'off' , 'ticklength' , [0 0] , 'fontsize' , 8 , 'units' , 'inches' , 'Position' , [0.25 0.25 1 1.125]);
 ax.YTick = [ax.YTick(1) ax.YTick(end)];
 ax.XTick = [0 ax.XTick(end)];
 ax.YLabel.String = 'Fraction';
 ax.XLabel.String = 'Value';
 hold on;
 plot([true_diff true_diff] , [0 ax.YTick(end)] , 'color' , 'r' , 'linestyle' , '-' , 'marker' , 'none' , 'linewidth' , 0.8)
 text(true_diff + 0.1*ax.XTick(end) , 0.9*ax.YTick(end) , num2str(P) , 'color' , 'r' , 'fontsize' , 8 , 'fontname' , 'arial');
 hold off;
 

