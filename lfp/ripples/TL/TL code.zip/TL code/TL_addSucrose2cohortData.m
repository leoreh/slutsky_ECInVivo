function TL_addSucrose2cohortData(cohortData , cohort)

folStr = [cd filesep 'Cohort ' cohort filesep];
excStr = [folStr 'behavior workbook.xls'];
if ~isfile(excStr)
    excStr = [excStr , 'x'];
end

[~ , ~ , exc] = xlsread(excStr , 'Sucrose');

headers = [exc(1,:)];
col.Group = find(strcmp(headers , 'Group'));
col.Subject = find(strcmp(headers , 'Subject'));
col.Date = find(strcmp(headers , 'Date'));
% indx for each group
ug = unique(exc(2:end , col.Group));
if length(ug) == 4
    ug = {'Control' , 'FST' , 'Isolated' , 'FST Isolated'};
end

allCols = {'k' , [0.0 0.7 0.7] , [0.4 0.4 0.4] , 'c'};
useCols = [allCols(1:length(ug))];

metaStr = [folStr , 'cohortData.mat'];
load(metaStr);


% Calculate learning preference and volume/hour for each mouse
strs = {'Water1','Water2','Water3','Sucrose1','Sucrose2','Sucrose3','Hour1','Hour2','Hour3'};
for s = 1 : length(strs)
    col.(strs{s}) = find(strcmp(headers ,strs{s}));
end

subs = exc(2:end,col.Subject);
grps = exc(2:end,col.Group);
dts = exc(2:end,col.Date);
learn.water = cell2mat(exc(2:end,col.Water1)) - cell2mat(exc(2:end,col.Water2));
hrs = cell2mat(exc(2:end,col.Hour2)) - cell2mat(exc(2:end,col.Hour1));
learn.water = learn.water ./ hrs;

learn.sucrose = cell2mat(exc(2:end,col.Sucrose1)) - cell2mat(exc(2:end,col.Sucrose2));
learn.sucrose = learn.sucrose ./ hrs;

test.water = cell2mat(exc(2:end,col.Water2)) - cell2mat(exc(2:end,col.Water3));
hrs = cell2mat(exc(2:end,col.Hour3)) - cell2mat(exc(2:end,col.Hour2));
test.water = test.water ./ hrs;

test.sucrose = cell2mat(exc(2:end,col.Sucrose2)) - cell2mat(exc(2:end,col.Sucrose3));
test.sucrose = test.sucrose ./ hrs;
clear hrs;

L = size(cohortData,2)
for s = 1 : length(subs)
    cohortData(L+1).Subject = subs{s};
    cohortData(L+1).Group = grps{s};
    cohortData(L+1).Date = dts{s};
    cohortData(L+1).Cohort = cohort;
    cohortData(L+1).WaterRateLearning = learn.water(s);
    cohortData(L+1).SucroseRateLearning = learn.sucrose(s);
    
        cohortData(L+1).WaterRateTest = test.water(s);
    cohortData(L+1).SucroseRateTest = test.sucrose(s);
    
    L = L + 1;
end


 save(metaStr , 'cohortData');




