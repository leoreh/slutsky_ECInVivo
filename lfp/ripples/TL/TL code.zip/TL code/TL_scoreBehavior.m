function [st , fi , key] = TL_scoreBehavior(dur)

global funStart st fi key dur;
funStart = [];
fi = [];
st = [];
key = {};

F = figure('units' , 'inches' , 'Position' , [7, 0.5 , 3 , 3] , ...
    'WindowKeyPressFcn' , @press , 'WindowKeyReleaseFcn' , @release , 'CreateFcn' , @controller , 'visible' , 'on');

uicontrol('parent' , F , 'style' , 'pushbutton' , ...
    'units' , 'inches' , 'position' , [0.025 0.025 2.95 2.95] , ...
    'fontname' , 'arial' , 'fontsize' , 10 , 'String' , 'Yee-haw!!!' , ...
    'callback' , @yeehaw);


tm = funStart;
while ~isempty(funStart) & tm < funStart + dur * 1e7
    tm = tic;
    if tm >= funStart + dur * 1e7
        makeGraph;
        break
    end
end
function controller(~,~)
global funStart
if ~isempty(funStart) && etime(clock , funStart) < dur
    fi; st; key;
    return
end

function funStart = yeehaw(~,~)
global funStart
funStart = clock;
return

function [fi , key] = release(~ , e)
global fi key funStart dur
while ~isempty(funStart) && etime(clock , funStart) < dur
fi(end+1) = toc;
key{end+1} = e.Key;
end

function [st , key , flag] = press(~ , e)
global st key funStart dur 
while ~isempty(funStart) && etime(clock , funStart) < dur
st(end+1) = toc;
key{end+1} = e.Key;
end

function makeGraph
x=1



