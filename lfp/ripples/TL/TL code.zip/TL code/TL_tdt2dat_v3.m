function expInfo = TL_tdt2dat_v3(expInfo , set)

% FUNCTION: uses information in expInfo, and the user-inputted set value to
% convert the appropriate tdt files to dat.

% v3: allows user to input start and end times in seconds from excxel
% spreadsheet (now in expInfo) to determine range of tdt2dat conversion for
% each set.
tic;

%% set some vars

setI = find(cell2mat(expInfo.set) == set);
scalef = 1e6;   % scale factor for int16 conversion [uV]
chunkSec = 100; % Length in seconds of each chunk of data converted at once
nblocks = length(setI); % number of blocks in this set
blocknames = [expInfo.blockName(setI)];
nsec = zeros(1, nblocks);
nsamps = zeros(1, nblocks);
data = [];

%%

for s = 1 : length(setI)
    
    sis = setI(s);
    store = expInfo.store{sis};
    
    if ~isstr(blocknames{s})
        blocknames{s} = num2str(blocknames{s});
    end
    
    fprintf(1, 'Working on dat conversion %s\n', blocknames{s});
    % open dat file
    if s == 1
        bp = expInfo.basepath{sis};
        if ~strcmp(bp(end) , filesep)
            bp = [bp , filesep];
        end
        
        fs = strfind(bp , filesep);
        datpath = [bp(1:fs(end-2)) , 'Subjects' , filesep , expInfo.subject{sis} , filesep , num2str(expInfo.date{sis}) , filesep];
        datname =  [datpath , store , '_Set' , num2str(set) '_' , num2str(expInfo.date{sis}) , '.dat'];
        if nargout == 1
            if ~isfolder(datpath)
                mkdir(datpath);
            end
            fout = fopen(datname, 'w');
            if(fout == -1)
                error('cannot open file');
            end
        end
    end
    
    % rearrange channels according to rmvch
    mapch = expInfo.channels{sis};
    rmvch = expInfo.rmvch{sis};
    mapch = mapch(~ismember(mapch, rmvch));
    nch = length(mapch);
    if sum(mapch > nch)
        mat = [unique(mapch); (1 : nch)]';
        for j = 1 : nch
            mapch(j) = mat(mat(:, 1) == mapch(j), 2);
        end
    end
    
    blockpath = [expInfo.basepath{sis} , filesep , blocknames{s}];
    fprintf(1, 'Working on %s\n', blocknames{s});
    t1 = expInfo.StartSec{sis}; if isnan(t1) , t1 = 0; end;
    t2 = expInfo.EndSec{sis}; if isnan(t2) , t2 = 0; end;
    heads = TDTbin2mat(blockpath, 'TYPE', {'streams'}, 'STORE', store, 'HEADERS' , 1 , 'T1' , t1 , 'T2' , t2);
    if isnan(expInfo.StartSec{setI(1)})
        sts = 0;
    else
        sts = expInfo.StartSec{setI(1)};
    end
    nsec(s) = heads.stores.(store).ts(end) - sts;
    clear sts;
    
    if isempty(chunkSec)       % load entire block
        nchunks = 1;
        chunks = [0 0];
    else                        % load block in chunks
        nchunks = ceil(nsec(s) / chunkSec);
        st = expInfo.StartSec{setI(1)};
        if isnan(st)
            st = 0;
        end
        chunks = st + [0 : chunkSec : chunkSec * (nchunks - 1);...
            chunkSec: chunkSec : chunkSec * nchunks]';
        if isinf(t2) | t2 == 0
        chunks(nchunks, 2) = 0;
        end
    end
    
    % adjust chunks according to user input in excel (now in expInfo)
    if t2 ~= 0
    chunks(chunks>=t2) = 0;
    chunks = chunks(any(chunks,2),:);
    chunks(end) = t2;
    nchunks = size(chunks , 1);
    end
    
    % clip unwanted times
    clipblk = expInfo.excludeS{sis};
    if ~isnan(clipblk)
        if isempty(chunkSec)
            if size(clipblk, 1) == 1 && clipblk(1) == 0
                chunks(1, 1) = clipblk(1, 2);
            elseif size(clipblk, 1) == 1 && clipblk(2) == Inf
                chunks(1, 2) = clipblk(1, 1);
            else
                for j = 1 : size(clipblk, 1) - 1
                    chunks = [chunks; clipblk(j, 2) clipblk(j + 1, 1)];
                end
            end
            if clipblk(1, 1) > 0
                chunks = [0 clipblk(1, 1); chunks];
            end
        else
            idx = zeros(1, 2);
            for j = 1 : size(clipblk, 1)
                idx(1) = find(chunks(:, 2) > clipblk(j, 1), 1, 'first');
                chunks(idx(1), 2) = clipblk(j, 1);
                if clipblk(j, 2) ~= Inf
                    idx(2) = find(chunks(:, 1) > clipblk(j, 2), 1, 'first');
                    chunks(idx(2), 1) = clipblk(j, 2);
                    rmblk = idx(1) + 1 : idx(2) - 1;
                else
                    rmblk = idx(1) + 1 : size(chunks, 1);
                end
                if ~isempty(rmblk)
                    chunks(rmblk, :) = [];
                end
            end
        end
        chunks = chunks(any(chunks, 2), :);
        nchunks = size(chunks, 1);
    end
%     heads.stores.(store).fs = 4091.8107132258;
    for j = 1 : nchunks
        dat = TDTbin2mat(blockpath, 'TYPE', {'streams'}, 'STORE', store,...
            'T1', chunks(j , 1) , 'T2' ,chunks(j , 2) );
        datI = dat.info;
        dat = dat.streams.(store).data;
        
        if ~isempty(dat)
            if ~isnan(rmvch)                     % remove channels
                dat(rmvch, :) = [];
            end
            
            if ~isempty(mapch)                     % remap channels
                dat = dat(mapch, :);
            end
            
            if nargout == 1
                fwrite(fout, dat(:), 'int16');     % write data
            elseif nargout == 2
                data = [data, dat];                % output data
            end
        end
        nsamps(s) = [nsamps(s) + size(dat, 2)];
    end
    
    expInfo.blockduration{sis} = nsec;
    expInfo.fs{sis} = heads.stores.(store).fs;
    expInfo.nsamps{sis} = nsamps(s);
    expInfo.nsec{sis} = nsec(s);
    
    temp = dir([blockpath , filesep , '*.tnt']);
    dnm = temp.datenum;
    
    sts = expInfo.StartSec{sis}/(24*60*60);
    if isnan(sts) , sts = 0; end;
    
    expInfo.startTime{sis} = dnm + sts;
    expInfo.endTime{sis} = sts + nsec(s)/(24*60*60);
    clear sts;
%     expInfo.startTime{sis} = datI.utcStartTime;
%     expInfo.stopTime{sis} = datI.utcStopTime;
%     expInfo.duration{sis} = datI.duration;
    expInfo.channels{sis} = mapch;
    
end

    if nargout == 1
        rc = fclose(fout);
        if rc == -1
            error('cannot save new file');
        end
        datInfo = dir(datname);
        fprintf(1, '\nCreated %s. \nFile size = %.2f MB\n', datname, datInfo.bytes / 1e6);
    end
    fprintf(1, '\nElapsed time = %.2f seconds\n', toc)
    
    
% save expInfo
fs = strfind(datname , filesep);
save([datname(1:(fs(end))) , expInfo.store{sis} '_expInfo.mat'] , 'expInfo');
end
