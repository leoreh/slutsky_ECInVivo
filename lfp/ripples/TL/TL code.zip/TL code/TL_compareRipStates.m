function TL_compareRipStates(cat)


%% set up some vars

% [stateList] : list of states in order of IDs used in AccuSleep
% [stateCols] : color codes for each respective state in stateList
stateList = {'activeWake', 'quietWake' , 'lightSleep' , 'NREM' , 'REM' , 'N/REM' , 'bin' , 'unknown'};
stateCols = [0.8 0 0; 1 0.25 0.25; 0.25 0.25 0.8; 0 0 0.8; 0.25 0.8 0.25; 0.4 0.4 0.4; 0.7 0.7 0.7; 1 1 1];

%% Create variables sampled at each second of recording

% [sleepSec] : Second of recording time corresponding to each value in
% cat.sleep
sleepSec = round(24*60*60*(cat.dayT - cat.start(1)) , 0);

% [badsleepI] : logical index for each second of recording that should not be used
% for analysis (eg the state could not be determined or there were
% artifacts)
badsleepI = cat.sleep == 7 | cat.sleep == 8;

% [zTheta/zDelta] : Theta and Delta power for each second, z-scored across the entire
% recording
zTheta = (cat.theta - nanmean(cat.theta(~badsleepI))) ./ nanstd(cat.theta(~badsleepI));
zDelta = (cat.delta - nanmean(cat.delta(~badsleepI))) ./ nanstd(cat.delta(~badsleepI));

% [ratio] : Delta/Theta ratio for each second across the entire recording
ratio = cat.delta ./ cat.theta;
ratio = (ratio - nanmean(ratio(~badsleepI))) ./ nanstd(ratio(~badsleepI));

% [zMua] : z-scored multi-unit activity for each second of recording
zMua = (cat.MuaHz - nanmean(cat.MuaHz(~badsleepI))) ./ nanstd(cat.MuaHz(~badsleepI));

% [zNonRipMua] : z-scored non ripple epoch firing rate
zNonRipMua = (cat.MuaNonRipHz - nanmean(cat.MuaNonRipHz(~badsleepI))) ./ nanstd(cat.MuaNonRipHz(~badsleepI));

fracSpikeInRip = cat.ripHz ./ cat.MuaHz;

%% Create variables smpled at each ripple

% [ripSec] : Second of recording time that each ripple occurs in (1st
% second is 0)
ripSec = round(floor((24*60*60)*(cat.catRip.DayT(:,1) - cat.start(1))),0);

% [sleepPerRip] : sleep state value for each ripple
% [ripDTh] : delta/theta ratio for each ripple
% [ripTheta] : z-scored theta power for each ripple
% [ripDelta] : z-scred delta power for each ripple
% [ripZmua] : z-scored multi-unit activity for each ripple
for r = 1 : length(ripSec)
    i = sleepSec == ripSec(r);
sleepPerRip(r) = cat.sleep(i);
ripDTh(r) = ratio(i);
ripTheta(r) = zTheta(i);
ripDelta(r) = zDelta(i);
ripZmua(r) = zMua(i);
end

% [sleephist] : number of seconds in each state
nPerState = histcounts(cat.sleep , [1:length(stateList)+1]);

% [nRipPerState] : number of ripples in each state
nRipPerState = histcounts(sleepPerRip , [1:length(stateList)+1]);

% [ripSleepRate] : rate of ripples in each state
ripSleepRate = nRipPerState ./ nPerState;

%% Extract epochs

% extract epochs for each state
[epochs] = TL_epochCat(cat);

%%
% Plot state distributions  total N in each state, and Rate in each
% state
F.stateDistr = figure('units' , 'inches' , 'position' , [0.5 0.5  8 8] , ...
    'Name' , 'Ripple Rate Per State' , 'visible' , 'on');
set(F.stateDistr , 'Renderer' , 'opengl');

ax.stateDistr.nPerState = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [0.5 6.5 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XTickLabelRotation' , 30 , 'XTick' , [1:5] , 'TickLength' , [0 0]);
hold on;
ax.stateDistr.nPerState.YLabel.String = 'Fraction of Time in State';
ax.stateDistr.nPerState.XLim = [0.25 5.75];
for b = 1 : 5
    bar(ax.stateDistr.nPerState , b , nPerState(b) / sum(nPerState([1:5])) , 1 , 'facecolor' , stateCols(b,:) , 'edgecolor' , 'k' , 'linewidth' , 0.5);
end
ax.stateDistr.nPerState.XTickLabels = [stateList(1:5)];

ax.stateDistr.nRipPerState = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [2 6.5 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XTickLabelRotation' , 30 , 'XTick' , [1:5] , 'TickLength' , [0 0]);
hold on;
ax.stateDistr.nRipPerState.YLabel.String = 'Fraction of Total Ripples';
ax.stateDistr.nRipPerState.XLim = [0.25 5.75];
for b = 1 : 5
    bar(ax.stateDistr.nRipPerState , b , nRipPerState(b) / sum(nRipPerState([1:5])) , 1 , 'facecolor' , stateCols(b,:) , 'edgecolor' , 'k' , 'linewidth' , 0.5);
end
ax.stateDistr.nRipPerState.XTickLabels = [stateList(1:5)];

ax.stateDistr.rate = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [0.5 5.0 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XTickLabelRotation' , 30 , 'XTick' , [1:5] , 'TickLength' , [0 0]);
hold on;
ax.stateDistr.rate.YLabel.String = 'Ripples/Second';
ax.stateDistr.rate.XLim = [0.25 5.75];
% accompanying cumulative distribution
ax.stateDistr.rateCumu = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position', [2 5.0 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1]);
hold on;
ax.stateDistr.rateCumu.YLabel.String = 'Cumulative Fraction';
ax.stateDistr.rateCumu.XLabel.String = 'Ripples/Second';
for b = 1 : 5
    s = sleepSec(cat.sleep == b);
    r = ripSec(sleepPerRip == b);
    h = [];
    for ss = 1 : length(s)
        h(end+1) = sum(r == s(ss));
    end
    ds = sort(h,'ascend');
    bar(ax.stateDistr.rate , b , ripSleepRate(b) , 1 , 'facecolor' , stateCols(b,:) , 'edgecolor' , 'k' , 'linewidth' , 0.5);
    plot(ax.stateDistr.rateCumu , [0 , ds] , [0 : length(ds)]/length(ds) , 'linewidth' , 1.25 , 'color' , stateCols(b,:) , 'marker' , 'none');
end
ax.stateDistr.rate.XTickLabels = [stateList(1:5)];

ax.stateDistr.fracSpikeInRipPerState = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [0.5 3.5 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'XTickLabelRotation' , 30 , 'XTick' , [1:5] , 'TickLength' , [0 0]);
hold on;
ax.stateDistr.fracSpikeInRipPerState.YLabel.String = 'Fraction MU Spikes in Ripple';
% accompanying cumulative distribution
ax.stateDistr.fracSpikeInRipPerStateCumu = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [2 3.5 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ... 
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
ax.stateDistr.fracSpikeInRipPerStateCumu.YLabel.String = 'Cumulative Fraction';
ax.stateDistr.fracSpikeInRipPerStateCumu.XLabel.String = 'Fraction of MU Spikes in Ripple';
for b = 1 : 5
    d = fracSpikeInRip(cat.sleep == b);
    ds = sort(d , 'ascend');
    m = mean(d);
    bar(ax.stateDistr.fracSpikeInRipPerState , b , m , 1 , 'facecolor' , stateCols(b,:) , 'edgecolor' , 'k' , 'linewidth' , 0.5);
     plot(ax.stateDistr.fracSpikeInRipPerStateCumu , [0 , ds] , [0 : length(ds)]/length(ds) , 'linewidth' , 1.25 , 'color' , stateCols(b,:) , 'marker' , 'none');
end
ax.stateDistr.fracSpikeInRipPerState.XTickLabels = [stateList(1:5)];

% accompanying cumulative distribution of raw ripple hz
ax.stateDistr.ripHzPerStateCumu = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [0.5 2.0 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
for b = 1 : 5
    d = cat.ripHz(cat.sleep == b);
    ds = sort(d , 'ascend');
     plot(ax.stateDistr.ripHzPerStateCumu , [0 , ds] , [0 : length(ds)]/length(ds) , 'linewidth' , 1.25 , 'color' , stateCols(b,:) , 'marker' , 'none');
end
ax.stateDistr.ripHzPerStateCumu.YLabel.String = 'Cumulative Fraction';
ax.stateDistr.ripHzPerStateCumu.XLabel.String = 'Ripple Spikes Per Second';

% accompanying cumulative distribution of raw ripple hz
ax.stateDistr.spikesPerRippleCumu = axes('parent' , F.stateDistr , 'units' , 'inches' , 'position' , [2.0 2.0 1.0 1.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
for b = 1 : 5
    d = cat.catRip.spkCnt(sleepPerRip == b)';
    ds = sort(d , 'ascend');
    plot(ax.stateDistr.spikesPerRippleCumu , [0 , ds] , [0 : length(ds)]/length(ds) , 'linewidth' , 1.25 , 'color' , stateCols(b,:) , 'marker' , 'none');
end
ax.stateDistr.spikesPerRippleCumu.YLabel.String = 'Cumulative Fraction';
ax.stateDistr.spikesPerRippleCumu.XLabel.String = 'Spikes Per Ripple';


%% Delta Theta Ratio
% Plot distribution of spikes per ripple per state
% Plot distribution of delta/theta ratio during the second of each ripple,
% by state
F.deltaTheta = figure('units' , 'inches' , 'position' , [1 0.5  6 8] , 'visible' , 'on');
set(F.deltaTheta , 'Renderer' , 'opengl');
ax.deltaTheta.histRip = axes('parent' , F.deltaTheta , 'units' , 'inches' , 'position' , [0.5 0.5 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;

% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h = histcounts(ripDTh , e);
%h = h / sum(h);
bar(ax.deltaTheta.histRip , e(1:end-1) , h , 'facecolor','k','edgecolor','k');
for s = 1 : 5
h = histcounts(ripDTh(sleepPerRip == s) , e);
 % h = h / sum(h);
stairs(ax.deltaTheta.histRip , e(1:end-1) , h , 'color' , stateCols(s,:),'linewidth' , 1.);
end
ax.deltaTheta.histRip.YLabel.String = '# Seconds';
ax.deltaTheta.histRip.XLabel.String = 'Delta:Theta Ratio';

ax.deltaTheta.histAllStates = axes('parent' , F.deltaTheta , 'units' , 'inches' , 'position' , [0.5 4 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;
% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h = histcounts(ratio , e);
% h = h / sum(h);
bar(ax.deltaTheta.histAllStates , e(1:end-1) , h , 'facecolor','k','edgecolor','k');
for s = 1 : 5
h = histcounts(ratio(cat.sleep == s) , e);
h = h/sum(h);
stairs(ax.deltaTheta.histAllStates , e(1:end-1) , h , 'color' , stateCols(s,:),'linewidth' , 1);
end
ax.deltaTheta.histAllStates.YLabel.String = 'Fraction of Seconds in State';
ax.deltaTheta.histAllStates.XLabel.String = 'Delta:Theta Ratio';

%% Z-scored Theta Power

% Plot distribution of spikes per ripple per state
% Plot distribution of delta/theta ratio during the second of each ripple,
% by state
F.Theta = figure('units' , 'inches' , 'position' , [1 0.5  6 8] , 'visible' , 'on');
set(F.Theta , 'Renderer' , 'opengl');
ax.Theta.histRip = axes('parent' , F.Theta , 'units' , 'inches' , 'position' , [0.5 0.5 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;

% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h = histcounts(ripTheta , e);
%h = h / sum(h);
bar(ax.Theta.histRip , e(1:end-1) , h , 'facecolor','k','edgecolor','k');
for s = 1 : 5
h = histcounts(ripTheta(sleepPerRip == s) , e);
%h = h / sum(h);
stairs(ax.Theta.histRip , e(1:end-1) , h , 'color' , stateCols(s,:),'linewidth' , 1.);
end
ax.Theta.histRip.YLabel.String = '# Seconds';
ax.Theta.histRip.XLabel.String = 'Z-scored Theta Power';

ax.Theta.histAllStates = axes('parent' , F.Theta , 'units' , 'inches' , 'position' , [0.5 4 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;
% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h = histcounts(zTheta , e);
% h = h / sum(h);
bar(ax.Theta.histAllStates , e(1:end-1) , h , 'facecolor','k','edgecolor','k');
for s = 1 : 5
h = histcounts(zTheta(cat.sleep == s) , e);
% h = h / sum(h);
stairs(ax.Theta.histAllStates , e(1:end-1) , h , 'color' , stateCols(s,:),'linewidth' , 1);
end
ax.Theta.histAllStates.YLabel.String = 'Fraction of Seconds in State';
ax.Theta.histAllStates.XLabel.String = 'Z-scored Theta Power';


%% Z-scored Delta Power

% Plot distribution of spikes per ripple per state
% Plot distribution of delta/theta ratio during the second of each ripple,
% by state
F.Delta = figure('units' , 'inches' , 'position' , [1 0.5  6 8] , 'visible' , 'on');
set(F.Delta , 'Renderer' , 'opengl');
ax.Delta.histRip = axes('parent' , F.Delta , 'units' , 'inches' , 'position' , [0.5 0.5 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;

% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h =  histcounts(ripDelta , e);
%  h = h / sum(h)
bar(ax.Delta.histRip , e(1:end-1) , h , 'facecolor','k','edgecolor','k');
for s = 1 : 5
h = histcounts(ripDelta(sleepPerRip == s) , e);
% h = h / sum(h);
stairs(ax.Delta.histRip , e(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
end
ax.Delta.histRip.YLabel.String = '# Seconds';
ax.Delta.histRip.XLabel.String = 'Z-scored Delta Power';

ax.Delta.histAllStates = axes('parent' , F.Delta , 'units' , 'inches' , 'position' , [0.5 4 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;

% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h = histcounts(zDelta , e);
% h = h / sum(h);
bar(ax.Delta.histAllStates , e(1:end-1) , h , 'facecolor' , 'k' , 'edgecolor' , 'k');
for s = 1 : 5
h = histcounts(zDelta(cat.sleep == s) , e);
% h = h / sum(h);
stairs(ax.Delta.histAllStates , e(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
end
ax.Delta.histAllStates.YLabel.String = 'Fraction of Seconds in State';
ax.Delta.histAllStates.XLabel.String = 'Z-scored Delta Power';

 %% Z-scored Firing Rate
 
 % Plot distribution of spikes per ripple per state
% Plot distribution of delta/theta ratio during the second of each ripple,
% by state
F.zMua = figure('units' , 'inches' , 'position' , [1 0.5  6 8] , 'visible' , 'on');
set(F.zMua , 'Renderer' , 'opengl');
ax.zMua.histRip = axes('parent' , F.zMua , 'units' , 'inches' , 'position' , [0.5 0.5 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;

% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h =  histcounts(ripZmua , e);
%  h = h / sum(h)
bar(ax.zMua.histRip , e(1:end-1) , h , 'facecolor','k','edgecolor','k');
for s = 1 : 5
h = histcounts(ripZmua(sleepPerRip == s) , e);
% h = h / sum(h);
stairs(ax.zMua.histRip , e(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
end
ax.zMua.histRip.YLabel.String = '# Seconds';
ax.zMua.histRip.XLabel.String = 'Z-scored MU Firing Rate';

ax.zMua.histAllStates = axes('parent' , F.zMua , 'units' , 'inches' , 'position' , [0.5 4 5.0 3.0] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
hold on;
% Plot distributions of delta/theta ratio of ripples occurring in each
% state and during all ripples
e = [-10 : 0.025 : 10];
h = histcounts(zMua , e);
% h = h / sum(h);
bar(ax.zMua.histAllStates , e(1:end-1) , h , 'facecolor' , 'k' , 'edgecolor' , 'k');
for s = 1 : 5
h = histcounts(zMua(cat.sleep == s) , e);
% h = h / sum(h);
stairs(ax.zMua.histAllStates , e(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
end
ax.zMua.histAllStates.YLabel.String = 'Fraction of Seconds in State';
ax.zMua.histAllStates.XLabel.String = 'Z-scored MU Firing Rate';

%% Compare post FST epochs to similarly timed nonFST epochs
temp = cellfun(@(z) strfind(z,'post FST') == 1 , cat.epochLabels , 'uniformoutput' , false);
fstI = find(cell2mat(cellfun(@(z) ~isempty(z) , temp , 'uniformoutput' , false)));
clear temp;

exclI = cat.sleep == 7 | cat.sleep == 8;
zMuaNonRip = (cat.MuaNonRipHz - mean(cat.MuaNonRipHz(~exclI))) / std(cat.MuaNonRipHz(~exclI));
e = [-10 : 0.25 : 10];
e2 = [0 : 2 : 100];
for f = 1 : length(fstI)
    epochT = cat.epochDayT(fstI(f));
    rangeFST(f,:) = [epochT , epochT + (120*60)/(24*60*60)];
    normT = rangeFST(f,:) - floor(rangeFST(f,:));
    i = find(cat.dayT >= rangeFST(f,1) & cat.dayT <= rangeFST(f,2));
    iRip = find(cat.catRip.DayT(:,1) >= rangeFST(f,1) & cat.catRip.DayT(:,1) <= rangeFST(f,2));
    sleepFST = cat.sleep(i);
    for s = 1 : 5
        i2 = sleepFST == s;
        i3 = i(i2);
        nonripZmua.FST{s} = zMuaNonRip(i3);
        iRip2 = sleepPerRip(iRip) == s;
        iRip3 = iRip(iRip2);
        ripSpkCnt.FST{s} = cat.catRip.spkCnt(iRip3);
    end
    clear i i2 i3 iRip iRip2
    % now find control epochs for this FST (because diff FSTs may be at
    % diff times..though should not be..)
    % find number of control, non FST days
    fstday = floor(rangeFST(f,1));
    alldays = floor(cat.start);
    cntrldays = [1:2]; %alldays(alldays ~= fstday);
    sleepCntrl = [];
    nonripZmua.Cntrl = cell(5,1);
    ripSpkCnt.Cntrl = cell(5,1);
    for c = 1 : length(cntrldays)
        rangeCntrl{f}(c , :) = repmat(cntrldays(c),1,2) + normT;
        i = find(cat.dayT >= rangeCntrl{f}(c,1) & cat.dayT <= rangeCntrl{f}(c,2));
         iRip = cat.catRip.DayT(:,1) >= rangeCntrl{f}(c,1) & cat.catRip.DayT(:,1) <= rangeCntrl{f}(c,1);
        sleepCntrl = [sleepCntrl, cat.sleep(i)];
        for s = 1 : 5
            i2 = cat.sleep(i) == s;
            i3 = i(i2);
            iRip2 = sleepPerRip(iRip) == s;
            iRip3 = iRip(iRip2);
            nonripZmua.Cntrl{s} = [nonripZmua.Cntrl{s} , zMuaNonRip(i3)];
            ripSpkCnt.Cntrl{s} = [ripSpkCnt.Cntrl{s} , cat.catRip.spkCnt(iRip3)];
        end
    end
    
    % Compare FST and cntrl epochs for each FST separately

    F.fst.nonRipzMua = figure('units' , 'inches' , 'position' , [1 0.5  6 8] , 'visible' , 'on');
    set(F.fst.nonRipzMua , 'Renderer' , 'opengl');
    ax.nonRipzMua.fst = axes('parent' , F.fst.nonRipzMua , 'units' , 'inches' , 'position' , [0.5 0.5 5.0 3.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
    hold on;
    for s = 1 : 5
        h = histcounts(nonripZmua.FST{s} , e);
        h = h / sum(h);
        stairs(ax.nonRipzMua.fst , e(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
    end
     ax.nonRipzMua.fst.YLabel.String = 'Fraction of Seconds in State';
 ax.nonRipzMua.fst.XLabel.String = 'Z-scored MU Firing Rate';
 
    ax.nonRipzMua.cntrl = axes('parent' , F.fst.nonRipzMua , 'units' , 'inches' , 'position' , [0.5 4 5.0 3.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
    hold on;
    for s = 1 : 5
        h = histcounts(nonripZmua.Cntrl{s} , e);
        h = h / sum(h);
        stairs(ax.nonRipzMua.cntrl , e(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
    end
      ax.nonRipzMua.cntrl.YLabel.String = 'Fraction of Seconds in State';
 ax.nonRipzMua.cntrl.XLabel.String = 'Z-scored MU Firing Rate';
 
 F.fst.ripSpkCnt = figure('units' , 'inches' , 'position' , [1 0.5  6 8] , 'visible' , 'on');
  set( F.fst.ripSpkCnt , 'Renderer' , 'opengl');
    ax.ripSpkCnt.fst = axes('parent' ,  F.fst.ripSpkCnt , 'units' , 'inches' , 'position' , [0.5 0.5 5.0 3.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
    hold on;
    for s = 1 : 5
        h = histcounts(ripSpkCnt.FST{s} , e2);
        h = h / sum(h);
        stairs(ax.ripSpkCnt.fst , e2(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
    end
    ax.ripSpkCnt.fst.YLabel.String = 'Fraction of Ripples in State';
 ax.ripSpkCnt.fst.XLabel.String = '# Spikes Per Ripple';
 
  ax.ripSpkCnt.cntrl = axes('parent' ,  F.fst.ripSpkCnt , 'units' , 'inches' , 'position' , [0.5 4 5.0 3.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8);% , 'XLim' , [-2 5] , 'XTick' , [-1:0.5:5]);
    hold on;
    for s = 1 : 5
        h = histcounts(ripSpkCnt.Cntrl{s} , e2);
        h = h / sum(h);
        stairs(ax.ripSpkCnt.cntrl , e2(1:end-1) , h , 'color' , stateCols(s,:) , 'linewidth' , 1);
    end
    ax.ripSpkCnt.cntrl.YLabel.String = 'Fraction of Ripples in State';
 ax.ripSpkCnt.cntrl.XLabel.String = '# Spikes Per Ripple';
 
end






%% Find "control" spiking events during active wake similar to ripples

% % % Find ISI distribution of spikes in ripples
% % ripSpkDayT = [];
% % for r = 1 : size(cat.catRip.DayT , 1)
% %     spkDayT = cat.catRip.spkT{r}/(24*60*60);
% %     if ~isempty(spkDayT)
% %         durDayT = cat.catRip.DayT(r,2) - cat.catRip.DayT(r,1);
% %         i = spkDayT > 0 & spkDayT < durDayT;
% %         keepSpkT = spkDayT(i);
% %         ripSpkDayT = [ripSpkDayT; keepSpkT + cat.catRip.DayT(r,1)];
% %     end
% % end
% 
% 
% 
% % For a first pass lets just call this 5 or more spikes within 50 ms, so
% % need to scroll thru 
% spt = [24*60*60*(cat.spt - cat.start(1))]';
% isi = diff(spt);
% mm=movsum(isi,[0,5]);
% 
% [hspt , e] = histcounts(spt , [0:0.010:24*60*60*(cat.stop(end) - cat.start(1))]);
% m = movsum(hspt,[0,5])';
% i = m >= 10;
% d(:,1) = find(diff([0;i]) == 1);
% d(:,2) = find(diff([i;0]) == -1)+4;
% newRange = []
% curr = d(1,:);
% for c = 2 : size(d , 1)
%     if d(c,1) <= curr(2)
%         curr = [curr(1) d(c,2)];
%     else
%         newRange = [newRange; curr];
%         curr = d(c,:);
%     end
% end
% 
% % iUse = d(:,2) - d(:,1) <= 15;
% % rangeUse = d(iUse,:);
% % for r = 1 : size(rangeUse , 1)
% %     spkCnt(r) = sum(hspt(rangeUse(r,:)));
% % end
% 
% % now find onset/offset times for each event
% cntrlDayT(:,1) = e(rangeUse(:,1))/(24*60*60);% + cat.start(1); 
% cntrlDayT(:,2) = e(rangeUse(:,2))/(24*60*60);% + cat.start(1);
% 
% % now keep only those events occurring during active wake
% % index each event into cat.sleep
% % TL temporary kludge because temp contains events at transitions between
% % recordings (beginning of gaps, prob because do not sleep score fraction
% % of a second in the end of a recording..)
% temp = floor(24*60*60*(cntrlDayT(:,1)));% - cat.start(1)));
% sleepT = round(24*60*60*(cat.dayT - cat.start(1)),0);
% keepI = ismember(temp,sleepT);
% temp = temp(keepI);
% cntrlDayT = cntrlDayT(keepI,:);
% 
% cntrlSleep = [];
% % Extract sleep state per control event
% for c = 1 : size(temp)
%     i = find(sleepT == temp(c));
%     cntrlSleep(c) = cat.sleep(i);
% end
% 
% cntrlDayT = cntrlDayT(cntrlSleep == 1,:);
% 
% % now find fraction of these that overlap with ripples
% ripDayT = cat.catRip.DayT - cat.start(1);
% excl = []
% for c = 1 : size(cntrlDayT , 1)
%    i = ripDayT >= cntrlDayT(c,1) & ripDayT <= cntrlDayT(c,2);
%    excl = [excl; find(i(:,1) & i(:,2))];
% end
% cntrlDayT(excl , :) = [];
%     
% % excl = find(

end


%%

% Plot distributions of z-scored spike rate occurring in each ripple in
% each state





% Plot Delta/Theta ratio leading up to each ripple

% Find similar spike rate distributions for 50 ms windows (or in the Nth percentile of ripple
% spike rate and opposite end of the delta-theta ratio (low ratio), mark
% those events as "feature-similar" events that can be compared to ripples,
% eg as a control. Is there something special about ripples, or do any
% events with similar spike rates relevant for plasticity, etc..













