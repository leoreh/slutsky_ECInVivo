function [data] = TL_epochCat(cat)

sleep = cat.sleep;
dayT = cat.dayT - floor(cat.start(1));
ripDayT = cat.catRip.DayT(:,1) - floor(cat.start(1));
ripZ = cat.catRip.zMua;
ripLog = cat.catRip.ripLog;
deltaTheta = cat.delta ./ cat.theta;
iexcl = sleep == 7 | sleep == 8;
deltaTheta = (deltaTheta - mean(deltaTheta(~iexcl)))/std(deltaTheta(~iexcl));

stateList = {'activeWake', 'quietWake' , 'lightSleep' , 'NREM' , 'REM' , 'N/REM' , 'bin' , 'unknown'};

% [statecols] : Color code for each state in stateList
stateCols = [0.8 0 0; 1 0.25 0.25; 0.25 0.25 0.8; 0 0 0.8; 0.25 0.8 0.25; 0.4 0.4 0.4; 0.7 0.7 0.7; 1 1 1];

% zscore the mua firing rate across the entire set of recording together
i = ~(sleep == 7 | sleep == 8); % exclude uncategorized epochs
mn = mean(cat.MuaHz(i));
sd = std(cat.MuaHz(i));
zTotal = (cat.MuaHz - mn)/sd;
clear i mn sd;

% Calculate slope between 2 points
slopeRip = [0 , diff(cat.ripHz)];
slopeNonRip = [ 0 , diff(cat.MuaNonRipHz)];

% slopeNonRip = abs(slopeNonRip);

% Extract all Epochs with their zscore'd mua (zscored across the entire set
% of recordings.

% TL combine wake epochs also if there is a 'bin' value in between as found
% in some recordings.. but just exclude that value later in analysis

% Combine active wake and quiet wake, later can split by delta-theta ratio:
logWake = sleep == find(cell2mat(cellfun(@(z) strcmp(z,'activeWake') , stateList , 'uniformoutput' , false))) |  ...
    sleep == find(cell2mat(cellfun(@(z) strcmp(z,'quietWake') , stateList , 'uniformoutput' , false)));
logWake = logWake';

EpochInd.Wake(:,1) = find(diff([0; logWake]) == 1);
EpochInd.Wake(:,2) = find(diff([logWake; 0]) == -1);

% -------------------------------------------------------------------------
% NREM, and combine epochs separated by lightsleep or quiet wake
logNREM = sleep == find(cell2mat(cellfun(@(z) strcmp(z,'NREM') , stateList , 'uniformoutput' , false)));
logNREM = logNREM';
temp(:,1) = find(diff([0; logNREM]) == 1);
temp(:,2) = find(diff([logNREM; 0]) == -1);

% find inter NREM epoch intervals that are less than 10 seconds, find if
% they only consist of quiet wake, light sleep, or N/REM, and if so then
% combine them
int = temp(2:end,1) - temp(1:end-1,2);

excl = [1:length(stateList)];
i = [find(cell2mat(cellfun(@(z) strcmp(z,'quietWake') , stateList , 'uniformoutput' , false))) ,
    find(cell2mat(cellfun(@(z) strcmp(z,'lightSleep') , stateList , 'uniformoutput' , false)))] ,
find(cell2mat(cellfun(@(z) strcmp(z,'N/REM') , stateList , 'uniformoutput' , false)));
excl = excl(~ismember(excl , i));

currEpoch = temp(1,:);
EpochInd.NREM = [];
for t = 2 : size(temp , 1)
    if int(t-1) <= 25 & sum(ismember(sleep(temp(t-1,2)+1 : temp(t,1) - 1) , excl)) == 0
        currEpoch = [currEpoch(1) , temp(t,2)];
    else
        EpochInd.NREM = [EpochInd.NREM ; currEpoch];
        currEpoch = temp(t,:);
    end
end

% -------------------------------------------------------------------------

% REM Epochs
logREM = sleep == find(cell2mat(cellfun(@(z) strcmp(z,'REM') , stateList , 'uniformoutput' , false)));
logREM = logREM';

EpochInd.REM(:,1) = find(diff([0; logREM]) == 1);
EpochInd.REM(:,2) = find(diff([logREM; 0]) == -1);

%% Extract zmua, ripple times, ripple zmua ,
fn = fieldnames(EpochInd);

for f = 1 : length(fn)
    
    for i = 1 : size(EpochInd.(fn{f}))
        r = [EpochInd.(fn{f})(i,1) : EpochInd.(fn{f})(i,2)];
        data.(fn{f}).zMua{i,1} = zTotal(r);
        
        data.(fn{f}).dayT{i,1} = dayT(r);
        
        data.(fn{f}).deltaTheta{i,1} = deltaTheta(r);
        
        data.(fn{f}).varZmua{i,1} = movvar(zTotal(r) , [0 ,5]);
        data.(fn{f}).ripSpikeFrac{i,1} = cat.ripHz(r) ./ cat.MuaHz(r);
        data.(fn{f}).slopeRip{i,1} = slopeRip(r);
        data.(fn{f}).varSlopeRip{i,1} = movvar(cat.ripHz(r) , 5);%movvar(slopeRip(r) , 5);
        data.(fn{f}).slopeNonRip{i,1} = slopeNonRip(r);
        data.(fn{f}).varSlopeNonRip{i,1} = movvar(cat.MuaNonRipHz(r) , 5);
        
        slopeRip = [0 , diff(cat.ripHz)];
        slopeNonRip = [ 0 , diff(cat.MuaNonRipHz)];
        
        
        
        ii = ripDayT >= dayT(r(1)) & ripDayT <= dayT(r(end));
        if sum(ii) > 0
            data.(fn{f}).ripDayT{i,1} = ripDayT(ii);
            
            % Loop thru ripples and extract peak zMua
            fi = find(ii);
            for ff = 1 : length(fi)
                pkZ(ff) = max(ripZ{fi(ff)}(ripLog{fi(ff)} == 1));
            end
            data.(fn{f}).pkZ{i,1} = pkZ;
            clear pkZ;
        else
            data.(fn{f}).ripDayT{i,1} = [];
            data.(fn{f}).pkZ{i,1} = [];
        end
    end
end
%% TL another option is to take the longest epoch that starts in NREM and ends in NREM that is 90% NREM classified







end