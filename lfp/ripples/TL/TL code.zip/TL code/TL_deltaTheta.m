function [nremI , wakeI , theta , delta , ratio] = TL_deltaTheta(lfp , sampRate , nremThresh , wakeThresh)

%% INPUTS:

% [lfp] = lfp data vector
% [sampRate] = sampling rate of lfp
% [nremThresh] = "low" threshold for nrem classification (TL uses 0.05 but should be empirically tested)
% [wakeThresh] = "high" threhsold for wake classification (TL uses -0.05
% but should be empirically tested)

%% OUTPUTS:
% [nremI] = logical index for each second of recording classified as nrem
% [wakeI = logical index for each second of recording classified as wake
% [theta] = theta power for each second
% [delta] = delta power for each second
% [ratio] = delta/theta ratio for each second

[~ , f , t , p] = spectrogram(lfp.data, sampRate , 0 , [1 : 1 : 12], sampRate, 'yaxis', 'psd');
delta = mean(p(f >= 1 & f <= 4 , :) , 1);
theta = mean(p(f >= 6 & f <= 12 , :) , 1);

% Test for artifacts -----------------------------------------------------
% due to artifacts skewing the zscore, i empirically found that
% over delta and theta values over 1e5 are definitely artifact, so
% convert these values to nan along with +/- 3 data points to be
% extra safe
id = delta > 1e5; it = theta > 1e5;
did = find(diff(id) == 1);
% pre-artifact
for d = 1 : length(did)
    if did(d) - 2 > 0
        id(did(d)-2:did(d)) = 1;
    else
        id(1:did(d)) = 1;
    end
end
clear did;
dit = find(diff(it) == 1);
for d = 1 : length(dit)
    if dit(d) - 2 > 0
        it(dit(d) - 2 : dit(d)) = 1;
    else
        it(1:dit(d)) = 1;
    end
end
clear dit;
% post-artifact
did = find(diff(id) == -1);
for d = 1 : length(did)
    if did(d) + 3 <= length(id)
        id(did(d):did(d)+3) = 1;
    else
        id(did(d) : end) = 1;
    end
end
clear did;
dit = find(diff(it) == -1);
for d = 1 : length(dit)
    if dit(d) + 3 <= length(it)
        it(dit(d) : dit(d) + 3) = 1;
    else
        it(dit(d) : end) = 1;
    end
end
clear dit;
delta(id) = nan; theta(it) = nan;
clear id it;
% ------------------------------------------------------------------------

ratio = delta ./ theta;
ratio = (ratio - nanmean(ratio)) / nanstd(ratio);
ratio = smoothdata(ratio , 'gaussian' , 60);
% sdtemp = std(ratio(~isnan(ratio) & ~isinf(ratio)));
% sd = std(ratio(~isnan(ratio) & ~isinf(ratio) & ratio < 10 * sdtemp));
if ~isempty(nremThresh) & ~isempty(wakeThresh)
nremI = ratio >= nremThresh
wakeI = ratio <= wakeThresh
else nremI = [];
    wakeI = [];
end
