function [ripDetect , ripCount] = TL_ripSearch_v5(lfp , muSpkSec , suSpkSec , expInfo , offsetSec)

%% Parameters for data

% % timestamps for lfp and spike data
% timestamps.tdt = ([1:size(raw,1)] - 1)/expInfo.rawSampRate;

bufferMs = 30; % Buffer in ms to save before and after each trace
% Integer number of samples in bufferMs
bufferSamp = round((bufferMs/1000) * expInfo.lfpSampRate,0);
% correct bufferMs due to rounding (because needed samples as integer)
bufferMs = 1000*bufferSamp/1250;

expInfo.bufferMs = bufferMs;

% # tdt samples to use in buffer
% tdtBuffSamp = floor((bufferMs/1000)*expInfo.rawSampRate);

% Threshold for detecting artifacts in the ulfiltered trace
unFilteredArtifact = 1500;

%% Filter the data, make normalizedSquaredSignal, and detect ripples based on standard deviation (lowThresholdFactor)

signal = bz_Filter(lfp.data , ...
    'filter' , 'butter' , 'passband' , [expInfo.highPass , expInfo.lowPass] ,'order' , 3);

% % Rms method moves along
%  sec2L = 2000 * expInfo.lfpSampRate;
%  ms8L = round(8/1000 * expInfo.lfpSampRate,0);
% 
%  rms2Buff = round(sec2L/2 , 0);
%  rms8Buff = round(ms8L/2 , 0);
%  tic
% for L = 1 : length(signal) - 2*rms2Buff
%     rms2s(L) = rms(signal(rms2Buff + L : 2*rms2Buff + L));
%     rms8ms(L) = rms(signal(rms8Buff + L : 2*rms8Buff + L));
% end
% toc
% 
% % zero pad the values
% rms2s = [zeros(1,rms2Buff) , rms2s , zeros(1,rms2Buff)];
% rms8ms = [zeros(1,rms2Buff) , rms8ms , zeros(1,rms2Buff)];
% 
% % Divide the 2 values
% rmsDivide = rms8ms ./ rms2s;

% Normalize the signal
% window for smoothing (11 samples)
windowLength = expInfo.lfpSampRate/expInfo.lfpSampRate*11;

% Square and normalize signal
squaredSignal = signal.^2;
% squaredSignal = abs(opsignal);
window = ones(windowLength,1)/windowLength;

% temporary kludge to remove artifacts
% squaredSignal(squaredSignal > 16e4) = 16e4;

% Basically, Filter0 makes all oscillatory epochs above 0 so they can be
% detected start to finish with thresholding without breaks (squared signal
% == 0 when normal signal intercepts y=0, thus would otherwise cause a break in the initially detected ripple.. 
% Then unity converts it to z-score, so the SDthreshold is really a magnitude of z-score. 

% First should remove artifacts so they don't interfere with the z-score
% calculation (normalizedSquaredSignal)
% remove artifacts for sd calculation...
p = sort(findpeaks(squaredSignal),'descend');
out = isoutlier(p , 'percentiles' , [0 , 99.99995]);
out2 = p>2*p(sum(out)+5);
% p = p(p(out) > 2 * p(sum(out)+5));
squaredSignal(squaredSignal > p(sum(out2)+1)) = mean(squaredSignal(squaredSignal <= p(sum(out2)+1)));
% squaredSignal((1.75e7:1.9e7)) = mean(squaredSignal(1:1.75e7));
filt0 = Filter0(window,sum(squaredSignal,2));
[normalizedSquaredSignal , sd] = unity(filt0,[],[]);

% Detect ripple periods by thresholding normalized squared signal
thresholded = normalizedSquaredSignal > expInfo.SDthresholdOnset;

% [start] : index for start of each ripple
% [stop] : index for stop of each ripple
start = find(diff(thresholded)>0);
stop = find(diff(thresholded)<0);
% Exclude last ripple if it is incomplete
if length(stop) == length(start)-1
    start = start(1:end-1);
end
% Exclude first ripple if it is incomplete
if length(stop)-1 == length(start)
    stop = stop(2:end);
end
% Correct special case when both first and last ripples are incomplete
if start(1) > stop(1)
    stop(1) = [];
    start(end) = [];
end

% [ripDetect.lfpIndx] : consolidates start and stop, used moving forward;
lfpIndx = [start,stop];
clear start stop;

%% Now go thru and merge ripples based on inter-ripple periods


% Show user how many events were detected by simple onset thresholding
if isempty(lfpIndx)
    disp('Detection by thresholding failed');
    return
else
    disp(['After detection by thresholding: ' num2str(length(lfpIndx)) ' events.']);
    % also save this info of how many ripples are detected
    ripCount.thresholding = size(lfpIndx , 1);
end

if ~isempty(expInfo.IRI)   
    %% Merge ripples if inter-ripple period is too short
    minInterRippleSamples = expInfo.IRI/1000*expInfo.lfpSampRate;
    tempStore = [];
    ripple = lfpIndx(1,:);
    for i = 2 : size(lfpIndx,1)
        if lfpIndx(i,1) - ripple(2) < minInterRippleSamples
            % Merge
            ripple = [ripple(1) lfpIndx(i,2)]; % TL now expand the end of the first ripple (combine the ripples)
        else
            tempStore = [tempStore ; ripple];
            ripple = lfpIndx(i,:);
        end
    end
    tempStore = [tempStore ; ripple];
    if isempty(tempStore)
        disp('Ripple merge failed');
        return
    else
        disp(['After ripple merge: ' num2str(length(tempStore)) ' events.']);
        ripCount.merging = size(tempStore , 1);
    end
else
    ripCount.merging = nan;
end
ripDetect.lfpIndx = tempStore;
clear lfpIndx tempStore ripple i;

%% Now throw out ripples whose peak power does not exceed the user inputted threshold (highThresholdFactor)
% Discard ripples with a peak power < highThresholdFactor

    tempStore = [];
    peakPower = [];
    % Loop thru ripples and erase ripples whose power does not exceed
    % the user inputted threshold (highThresholdFactor)
    for i = 1:size(ripDetect.lfpIndx,1)
        [maxValue,maxIndex] = max(normalizedSquaredSignal([ripDetect.lfpIndx(i,1):ripDetect.lfpIndx(i,2)]));
        if maxValue > expInfo.SDthresholdPeak
            tempStore = [tempStore ; ripDetect.lfpIndx(i,:)];
            m = max(squaredSignal([ripDetect.lfpIndx(i,1):ripDetect.lfpIndx(i,2)])); % use the raw voltage value not normalized to sd
            peakPower = [peakPower ; m]; %Save peak Power
            clear m;
        end
    end
    if isempty(tempStore)
        disp('Peak thresholding failed.');
        return
    else
        disp(['After peak thresholding: ' num2str(length(tempStore)) ' events.']);
        ripCount.peakPower = size(tempStore , 1);
    end
    
    clear maxValue maxIndex i;
    
    % Detect negative peak position for each ripple (from the filtered trace
    % not squared or normalized)
    peakPosition = zeros(size(tempStore,1),1);
    for i=1:size(tempStore,1)
        [minValue,minIndex] = min(signal(tempStore(i,1):tempStore(i,2)));
        peakPosition(i) = minIndex + tempStore(i,1) - 1;
    end
    
    ripDetect.peakNormalizedPower = peakPower;
    ripDetect.peakPosition = peakPosition;
    ripDetect.lfpIndx = tempStore;
    ripDetect.durationMs = 1000*(ripDetect.lfpIndx(:,2) - ripDetect.lfpIndx(:,1))/expInfo.lfpSampRate;
    clear peakNormalizedPower peakPosition tempStore i;

%% Throw out ripples that are too long or too short or have artifact in raw tdt trace

% Discard ripples that are too long or too short

    incl = ripDetect.durationMs < expInfo.maxDuration & ripDetect.durationMs > expInfo.minDuration;
    
    ffn = fieldnames(ripDetect);
    for f = 1 : length(ffn)
        ripDetect.(ffn{f}) = ripDetect.(ffn{f})(incl,:);
    end
    clear incl durMs f;
    disp(['After duration test: ' num2str(size(ripDetect.lfpIndx , 1)) ' events.']);
    ripCount.length = size(ripDetect.lfpIndx , 1);
    
    % Discard ripples that occur too soon to include a baseline period or too
    % late to include a follow up period
    incl = ripDetect.lfpIndx(:,1) > bufferSamp & ripDetect.lfpIndx(:,2) < length(lfp.data) - bufferSamp;
    for f = 1 : length(ffn)
        ripDetect.(ffn{f}) = ripDetect.(ffn{f})(incl,:);
    end
    clear incl f;
clear m;
%% Now extract unfiltered traces,lfp traces bandpassed for ripples, and multiunit spike times for each ripple

    % temporary variablez.
    Li = ripDetect.lfpIndx;
    uF = cell(size(Li,1),1);
    rip = cell(size(uF));
    lR = cell(size(rip));
    mu = cell(size(lR));
    
    for i = 1 : size(Li , 1)
        
        iStart = Li(i,1) - bufferSamp;
        iStop = Li(i,2) + bufferSamp - 1;
        uF{i,1} = lfp.data(iStart : iStop) ...
            - mean(lfp.data(iStart : Li(i,1) - 1));
        rip{i,1} = signal(iStart : iStop) ...
            - mean(signal(iStart : Li(i,1) - 1));
        
        temp = ones(length(uF{i,1}) , 1);
        temp([1:bufferSamp , end - bufferSamp + 1:end]) = 0;
        lR{i,1} = logical(temp);
        clear temp;
        
        mu{i,1} = 1000 * (muSpkSec(muSpkSec >= (iStart/expInfo.lfpSampRate) + offsetSec & muSpkSec <= (iStop/expInfo.lfpSampRate) + offsetSec) - Li(i,1)/expInfo.lfpSampRate - offsetSec);
    end
    clear i;
    
    ripDetect.unFilt = uF;
    ripDetect.ripple = rip;
    ripDetect.logRip = lR;
    ripDetect.muSpkTimesMs = mu;
    clear Li uF rip lR mu;
clear m fn;

%% Now throw out ripples that do not recruit increased multi-unit spiking

    incl = [];
    
        % temporary variablez.
    Li = ripDetect.lfpIndx;
    dur = ripDetect.durationMs;
    mu = ripDetect.muSpkTimesMs;
    
    for i = 1 : size(Li , 1)
        
        blHz(i) = sum(mu{i} < 0)/(expInfo.bufferMs/1000);
        evkHz(i) = sum(mu{i} >= 0 & mu{i} <= dur(i))/(dur(i)/1000);
        
%         blHz = sum(mu{i} < expInfo.bufferMs)/(expInfo.bufferMs/1000);
%         evkHz = sum(mu{i} >= expInfo.bufferMs & mu{i} <= expInfo.bufferMs + dur(i))/(dur(i)/1000);
        incl(i) = evkHz(i) > 1.25 * blHz(i);
    end
    clear i;
    
    incl = logical(incl);
    ffn = fieldnames(ripDetect);
    for f = 1 : length(ffn)
        ripDetect.(ffn{f}) = ripDetect.(ffn{f})(incl,:);
    end
    clear f;
    ripCount.mua = sum(incl);
    
    clear Li dur mu;
clear m incl;
%% Now throw out ripples with artifact in the unfiltered trace
% NEED TO BASELINE SUBTRACT EACH TRACE..

incl = cell2mat(cellfun(@(z) sum(abs(z) > 1500) == 0 , ripDetect.unFilt , 'uniformoutput' , false));
incl = logical(incl);

    ffn = fieldnames(ripDetect);
    for f = 1 : length(ffn)
        ripDetect.(ffn{f}) = ripDetect.(ffn{f})(incl,:);
    end
    clear f;
    ripCount.art = sum(incl);

%% Find single unit spiking to each ripple

% concatenate spiketimes from all single units and index them based on cell
% number
suNum = [];
for s = 1 : length(suSpkSec)
    suNum = [suNum ; ones(length(suSpkSec{s}),1) * s];
end
clear s;

spkt = vertcat(suSpkSec{:});
[spkt , order] = sort(spkt , 'ascend');
suNum = suNum(order);

    Li = ripDetect.lfpIndx;
    sr = expInfo.lfpSampRate;
    for s = 1 : size(ripDetect.peakPosition , 1)
        i = spkt >= Li(s,1)/sr - bufferMs/1000 ...
            & spkt <= Li(s,1)/sr + bufferMs/1000;
        ripDetect.sua{s,1}.spkt = 1000*(spkt(i) - Li(s,1)/sr);
        ripDetect.sua{s,1}.suNum = suNum(i);
        clear i;
    end
    clear s Li sr;

clear m spkt suNum fn order;

%% Great job, now add the offset in seconds to each relevant field in ripDetect and add a field for timestamps

offsetIndx = offsetSec * expInfo.lfpSampRate;

    ripDetect.lfpIndx = ripDetect.lfpIndx + offsetIndx;
    ripDetect.peakPosition = ripDetect.peakPosition + offsetIndx;
    
    for s = 1 : length(ripDetect.sua)
        ripDetect.sua{s}.spkt = ripDetect.sua{s}.spkt + offsetSec;
    end

ripDetect.bufferMs = bufferMs;
%% Some functions..

    function y = Filter0(b,x)
        
        if size(x,1) == 1
            x = x(:);
        end
        
        if mod(length(b),2)~=1
            error('filter order should be odd');
        end
        
        shift = (length(b)-1)/2;
        
        [y0 z] = filter(b,1,x);
        
        y = [y0(shift+1:end,:) ; z(1:shift,:)];
    

    function [U,stdA] = unity(A,sd,restrict)
        
        if ~isempty(restrict)
            meanA = mean(A(restrict));
            stdA = std(A(restrict));
        else
            meanA = mean(A);
            stdA = std(A);
        end
        if ~isempty(sd)
            stdA = sd;
        end
        
        U = (A - meanA)/stdA;
    















