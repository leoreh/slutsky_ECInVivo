function [sleep , delta , theta , ratio] = TL_extractSleep(pathname , varargin)

if ~strcmp(pathname(end) , filesep)
    pathname = [pathname , filesep];
end

stateList = {'activeWake', 'quietWake' , 'lightSleep' , 'NREM' , 'REM' , 'bin' , 'unknown'};

sleepFileDir= dir([pathname , filesep ,  '*SleepState.states*']);

% refaela did not give all same sleepstate structure formats per day so
% need to parse this out...
if ~isempty(sleepFileDir) % If she gave the 'SleepState' structure..
    sleepFile = load([pathname , filesep  , sleepFileDir.name]);
    sleep = sleepFile.SleepState;
    clear sleepFile
    
    % Standardize sleep state values to stateList variable
    % Alter state names (Not all states may have been included, and they may
    % have been entered with a different name)
    og = sleep.idx.statenames;
    i = find(strcmp(og, 'WAKE'));
    if ~isempty(i)
        og{i} = 'activeWake';
    end
    [uS , uI] = unique(og);
    i = cell2mat(cellfun(@(z) ~isempty(z) , uS , 'uniformoutput' , false));
    uS = uS(i);
    uI = uI(i);
    for u = 1 : length(uS)
        newVal = find(strcmp(stateList , uS{u}));
        sleep.idx.states(sleep.idx.states == uI(u)) = newVal;
        %     data.ripList.states([data.ripList.states == uI(u)]) = newVal;
    end
    clear og i uS uI i uS uI u newVal;
    
else % if she gave the 'SleepStateEpisodes' instead of SleepState'...
    % make 'SleepState.idx.states'
    clear SleepState;
    sleepFile = dir([pathname , filesep ,  '*SleepStateEpisodes.states*']);
    if ~isempty(sleepFile)
        load([pathname , recDates{r} , filesep  , sleepFile.name]);
        
        fn = fieldnames(SleepStateEpisodes.ints);
        i = cellfun(@(z) strfind(z , 'episode'), fn , 'uniformoutput',false);
        i = ~cellfun(@isempty , i);
        fn = [fn(i)];
        for f = 1 : length(fn)
            d = SleepStateEpisodes.ints.(fn{f});
            if strfind(fn{f},'WAKE')
                val = 1;
            end
            if strfind(fn{f},'NREM')
                val = 4;
            end
            if strfind(fn{f},'REM') == 1
                val = 5;
            end
            for dd = 1 : size(d,1)
                sleep.idx.states([d(dd,1):d(dd,2)]) = val;
            end
            sleep.idx.states =  sleep.idx.states';
        end
    else
        % if there is no sleep file at all, then calculate theta delta
        % ratio for the whole recording, and classify into NREM, WAKE,
        % and unknown
        
%        lfpFile = dir([pathname , filesep ,  '*lfp.mat*']);
%         load([pathname , filesep  , lfpFile.name]);
%         lfp = lfp.data(1,:);


if ~isempty(varargin)
    expInfo = varargin{1};
    if length(varargin) == 2
        ch2use = varargin{2};
    else ch2use = 1;
    end
else
    temp = dir([pathname '*expInfo.mat']);
i = find(cell2mat(cellfun(@(z) ~isempty(z) , strfind({temp.name} , 'Raw') , 'uniformoutput' , false)));
load([pathname , temp(i).name]);
clear temp i;
ch2use = 1;
end

        % adapted from Yamamoto & Tonegawa 2017
          [lfp , ~] = TL_getLFPtest('basepath' , pathname , 'type' , 'filt' , 'ch' , ch2use , 'fs' , 1250 , 'nchans' , length(expInfo.channels{1}) , ...
            'extension' , 'lfp' , 'savevar' , false , 'forceL' , true);
                [~ , f , t , p] = spectrogram(lfp.data, 1250 , 0 , [1 : 1 : 12], 1250, 'yaxis', 'psd');
        delta = mean(p(f >= 1 & f <= 4 , :) , 1);
        theta = mean(p(f >= 6 & f <= 12 , :) , 1);
        
        % due to artifacts skewing the zscore, i empirically found that
        % over delta and theta values over 1e5 are definitely artifact, so
        % convert these values to nan along with +/- 3 data points to be
        % extra safe
        id = delta > 1e5; it = theta > 1e5;
        did = find(diff(id) == 1);
        % pre-artifact
        for d = 1 : length(did)
            if did(d) - 2 > 0
            id(did(d)-2:did(d)) = 1;
            else
                id(1:did(d)) = 1;
            end
        end
        clear did;
        dit = find(diff(it) == 1);
        for d = 1 : length(dit)
            if dit(d) - 2 > 0
            it(dit(d) - 2 : dit(d)) = 1;
            else
                it(1:dit(d)) = 1;
            end
        end
        clear dit;
        % post-artifact
        did = find(diff(id) == -1);
        for d = 1 : length(did)
            if did(d) + 3 <= length(id)
            id(did(d):did(d)+3) = 1;
            else
                id(did(d) : end) = 1;
            end
        end
        clear did;
        dit = find(diff(it) == -1);
        for d = 1 : length(dit)
            if dit(d) + 3 <= length(it)
            it(dit(d) : dit(d) + 3) = 1;
            else
                it(dit(d) : end) = 1;
            end
        end
        clear dit;
        delta(id) = nan; theta(it) = nan;
        clear id it;
        
%         zdelta = (delta - nanmean(delta))/nanstd(delta);
%         ztheta = (theta - nanmean(theta))/nanstd(theta);
%         delta = (delta - min(delta)) ./ (max(delta) - min(delta));
%         theta = (theta - min(theta)) ./ (max(theta) - min(theta));
        ratio = delta ./ theta;
        ratio = (ratio - nanmean(ratio)) / nanstd(ratio);
        ratio = smoothdata(ratio , 'gaussian' , 60);
        sdtemp = std(ratio(~isnan(ratio) & ~isinf(ratio)));
        sd = std(ratio(~isnan(ratio) & ~isinf(ratio) & ratio < 10 * sdtemp));
        nremI = ratio >= 0.05
        wakeI = ratio <= -0.05
        sleep.idx.states = nan(size(ratio));
        sleep.idx.states(nremI) = 4;
        sleep.idx.states(wakeI) = 1;
        sleep.idx.states(~nremI & ~wakeI) = 7;

    end
end
sleep = sleep.idx.states;

