function [ripDetect , ripCount] = TL_ripDetect_v2(filtLFP , unfiltLFP , vars , sleep , mua)

%% Ripple detection based on Boone..Foster 2018 with changes to onset threshold z-scored magnitude
% minimum inter-ripple interval, and min time above peak z-scored
% threshold. Parameters were tested using TL_compareRipDetectMethods for
% optimization. Does not use multi-unit activity criteria but this can be
% saved and added to the ripple structure separately. This code just gives
% the onset and offset indices of each ripple, and displays how many
% ripples were lost at each filtering step

% v2 : just clearing some unneeded variables to avoid storage problems

%% Inputs:
% [allLFP] : cell array, each cell is the lfp.data output from TL_getLFP
% for the 3 ripple channels chosen (find best rms channel from each
% tetrode, then take the 3 best of these)

%% Original Boone..Foster 2018 detection protocol (other protocols can be found in TL_rippleWrapper_v5

% LFP and spike data were analyzed in these different wake and sleep states.
% SWRs (marked in red in Fig. 2A) were detected as follows: The three electrodes,
% per hemisphere, with the largest amplitude ripple activity were included in the LFP analysis.
% The z-scored LFP signal of each electrode during �slow-wave sleep or quiet wakefulness� (SWS/QW)
% periods was denoised for 60-Hz electrical noise and its 180-Hz harmonic using a second-order IIR
% notch filter. Denoised LFP during SWS/QW periods was filtered in ripple frequency range
% (100�250?Hz) with a fifth-order Butterworth band-pass filter.
% The envelopes of each band-passed LFP trace were the absolute value of its Hilbert transform.
% These envelopes were averaged over the three electrodes/hemisphere and smoothed with Gaussian
% 5-ms standard deviation (SD) smoother. Each event for which the envelope amplitude exceeds
% a threshold of 3 SD above the mean amplitude for more than 3?ms was considered a SWR,
% and SWRs that were less than 20?ms apart were merged and were considered as one extended event.
% The start and end of each SWR were the times when the smoothed envelope crossed its mean value.
% An analysis, in which the parameters of threshold for SWR detection varied from 1 to 6 SD,
% was conducted to determine the robustness of the findings.

%% Do math

logNREM = sleep == 4;
logNREM = repelem(logNREM , 1250);
L = length(filtLFP{1});
if L < length(logNREM)
logNREM = logNREM(1:length(filtLFP{1}));
end
if L > length(logNREM)
    filtLFP = cellfun(@(z) z(1:length(logNREM)) , filtLFP , 'uniformoutput' , false);
end

summedSmoov = 0;
summedPhase = 0;
summedFilt = 0;
for a = 1 : length(filtLFP)
    lfp = filtLFP{a};
    
    % Z-score the entire LFP signal to the NREM mean and standard deviation
    mn = mean(lfp(logNREM));
    sd = std(lfp(logNREM));
    zlfp = (lfp - mn)/sd;
    clear lfp; 
    
    % Construct coefficients for butterworth bandpass filter
    [c1 , c2] = butter(5,[100 250]/(1250/2),'bandpass');
    
    % Run butterworth Filter
    f = filtfilt(c1,c2,double(zlfp));
    clear c1 c2 zlfp;
    
    % Run Hilbert Transform
    h = hilbert(f);
    
    % Extract transformed signal and phase from Hilbert Transform
%     hilb{a} = h;
    amp = abs(h);
    phase{a} = angle(h);
    clear h;
    
    % Smooth with moving gaussian filter
    sm = smoothdata(amp , 'gaussian' , round(5/(1000/1250),0));
    clear amp;
    summedSmoov = summedSmoov + sm;
    clear sm;
    
    summedPhase = summedPhase + phase{a};
    
    summedFilt = summedFilt + f;
    clear f;
end

meanSmoov = summedSmoov / length(filtLFP);
clear summedSmoov;

zSmoov = (meanSmoov - mean(meanSmoov))/std(meanSmoov);

meanPhase = summedPhase / length(filtLFP);
meanFilt = summedFilt / length(filtLFP);

% threshPeak = 4 * sdRaw + mean(meanSmoov);
threshPeak = vars(1);
threshOn = vars(2);
peakMs = vars(3);
mergeMs = vars(4);

peakSamps = (peakMs/1000)/(1/1250);
mergeSamps = (mergeMs/1000)/(1/1250);
%% First pass, find ripples based on peak threshold

thresholded = zSmoov > threshPeak;

pos = find(diff(thresholded) == 1) + 1;
neg = find(diff(thresholded) == -1);
if length(pos) > length(neg)
    pos = pos(1:end-1);
else if length(neg) > length(pos)
        neg = neg(2:end);
    end
end
tempStore = [pos , neg];
tempStore = tempStore(neg-pos>=peakSamps , :);

ripDetect.lfpIndx = tempStore;
ripCount.onset = size(tempStore , 1);
clear tempStore thresholded pos neg;

%% Expand ripple boundaries to z(abs(hilb)) == threshOn
thresholded = zSmoov > threshOn;

pos = find(diff(thresholded) == 1) + 1;
neg = find(diff(thresholded) == -1);

Li = ripDetect.lfpIndx;
tempStore = [];
currRip = Li(1 , :);
for L = 2 : size(Li)
    if L == 1201
    end
    p = pos(pos <= currRip(1));
    p = p(end);
    n = neg(neg >= currRip(2));
    n = n(1);
    
    if ~isempty(p) & ~isempty(n)
        currRip = [p , n];
    end
    if Li(L,1) <= currRip(2)
        currRip = [p , Li(L,2)];
    else
        tempStore = [tempStore; currRip];
        currRip = Li(L , :);
    end
end

ripDetect.lfpIndx = tempStore;
ripCount.onset = size(tempStore , 1);
clear tempStore p n pos neg Li L;

%% Extract phase, envelope, unfiltered trace, and filtered trace in each ripple

Li = ripDetect.lfpIndx;

bufferLfpSamps = (20/1000)*1250;
bufferLfpMs = bufferLfpSamps/1250;

for L = 1 : size(Li , 1)
    range(1) = Li(L,1) - bufferLfpSamps;
    range(2) = Li(L,2) + bufferLfpSamps;
    range = range(1) : range(2);
    % In case range goes out of recording limits
    buffPre = bufferLfpSamps - sum(range <= 0);
    buffPost = bufferLfpSamps - sum(range > length(meanSmoov));
    
    
    range = range(range > 0 & range <= length(meanSmoov));
%     range<0
    phase{L,1} = meanPhase(range);
    
    envelope{L,1} = meanSmoov(range);
    
    unfiltered{L,1} = unfiltLFP(range*10) - mean(unfiltLFP(range(1:buffPre)*10));
    
    filtered{L,1} = meanFilt(range) - mean(meanFilt(range(1:buffPre)));
    
    temp = ones(length(range) , 1);
    temp([1:buffPre, end-buffPost+1:end]) = 0;
    ripLog{L,1} = temp; clear temp;
end

ripDetect.phase = phase;
ripDetect.envelope = envelope;
ripDetect.unfiltered = unfiltered;
ripDetect.filtered = filtered;
ripDetect.ripLog = ripLog;

%% Remove artifact traces

removArt = ~cell2mat(cellfun(@(z) max(abs(z))>2000 , ripDetect.unfiltered , 'uniformoutput' , false));

fn = fieldnames(ripDetect);
for f = 1 : length(fn)
    ripDetect.(fn{f}) = ripDetect.(fn{f})(removArt , :);
end

%% Extract z-scored multi-unit activity in each ripple and mu spike times

bufferTdtSamps = round(24414.06 * bufferLfpMs/1000 , 0);
bufferTdtMs = 1000 * bufferTdtSamps / 24414.06;

lfp = filtLFP{1};
binRate = 5/1000;
% Bin mua spikes and convert to hz
e = [0 : binRate : length(lfp)/1250];
if e(end) ~= length(lfp)/1250
    e(end+1) = length(lfp/1250);
end
if mua(end) > length(lfp)
    e(end+1) = mua(end);
end

muaBinnedCounts = histcounts(mua , e);
muaBinnedHz = muaBinnedCounts / binRate;
if e(end) == mua(end)
    muaBinnedHz(end) = muaBinnedCounts(end)/(e(end)-e(end-1));
end

smMuaBinnedHz = smoothdata(muaBinnedHz , 'gaussian' , 5);
tstamp = e + binRate/2;
tstamp = tstamp(1:end-1);

m = mean(smMuaBinnedHz);
sd = std(smMuaBinnedHz);
zMua = (smMuaBinnedHz - m)/sd;


% for ease of plotting and analysis later on, resample zMua to 1/1250 (lfp
% sample rate)
zMua = resample(zMua , (1/1250)^-1 , binRate^-1);

% now loop thru ripples and make sure instantaneous firing rate went above
% 3 sds during the ripple

Li = ripDetect.lfpIndx;
Lt = Li / 1250;

for L = 1 : size(Lt , 1)
    
     range(1) = Li(L,1) - bufferLfpSamps;
    range(2) = Li(L,2) + bufferLfpSamps;
    range = range(1) : range(2);
    
    % In case range goes out of recording limits
    buffPre = bufferLfpSamps - sum(range <= 0);
    buffPost = bufferLfpSamps - sum(range > length(zMua)); 
     range = range(range > 0 & range <= length(zMua));
     
     zm{L,1} = zMua(range);
     f
      temp = ones(length(range) , 1);
    temp([1:buffPre, end-buffPost+1:end]) = 0;
    zmuaLog{L,1} = temp; clear temp;
     
    temp = ones(length(zm{L,1}),1);
    temp([1:bufferTdtSamps, end - bufferTdtSamps + 1 : end]) = 0;
    logZmua{L,1} = temp; clear temp;
    
    i = mua >= Lt(L,1) - bufferTdtMs/1000 & mua < Lt(L,2) + bufferTdtMs/1000;
    spkT{L,1} = mua(i) - Lt(L,1);
end

ripDetect.zMua = zm;
ripDetect.logZmua = logZmua;
ripDetect.spkT = spkT;


