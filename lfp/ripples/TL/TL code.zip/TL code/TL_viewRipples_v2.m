function TL_viewRipples_v2(ripples , normalize , cr , sortVar , sortDir , bursts)

%% Tool to view data from a single recording (not catMouse output)
% Runs on output of TL_ripDetect

% INPUTS -> 

% [data] : ripple structure output from TL_ripDetect
% [n] : 1 to n axes across all data, 0 to not
% [currentRip] : index of ripple to display initially
% [sortVar] : variable to sort the data by.
    % options : 'time' , 'length' , 'power' , 'spikes'
% [sortdir] : 'ascend' or 'descend'
% [bursts] : look at bursts of data instead of single data

%% global vars
currentRip = [];
data = [];
indx = [];
muRange = [];
muH = [];
clear n data currentRip ax aspRat;

global n data ax currentRip aspRat axSpkt ylimz indx muRange muH;

currentRip = cr; clear cr;
ax= [];
ylimz = [];
n = normalize;
data = ripples.detect;

%% Bin mu spiketimes for histogram (5 ms bins)
for d = 1 : length(data.spkT)
    df = diff(data.ripLog{d});
    buffPre = find(df ,  1);
    rangePre = [0 : 5/1000 : buffPre * 1/1250];
    if rangePre(end) ~= buffPre/1250
        rangePre(end+1) = buffPre/1250;
    end
    rangePre = -flip(rangePre);

    muRange{d} = [rangePre , 5/1000 : 5/1000 : (length(data.ripLog{d}) - buffPre)/1250];
    if muRange{d}(end) ~= (length(data.ripLog{d}) - buffPre)/1250
        muRange{d}(end+1) = (length(data.ripLog{d}) - buffPre)/1250;
    end
    h = histcounts(data.spkT{d} , muRange{d});
    r = resample(h , 1250/1 , 1000/5);
    muH{d} = r(1:length(data.ripLog{d}));
%     buffPost = length(data.ripLog) - find(df == -1 , 1) + 1;
end 
%% Arrange data


fn = fieldnames(data);

if strcmp(sortVar , 'time')
    [~ , indx] = sort(data.lfpIndx(: , 1) , sortDir);
    for f = 1 : length(fn)
        data.(fn{f}) = data.(fn{f})(indx,:);
    end
end

if strcmp(sortVar , 'length')
    dur = data.lfpIndx(:,2) - data.lfpIndx(:,1);
    [~ , indx] = sort(dur , sortDir);
    for f = 1 : length(fn)
        data.(fn{f}) = data.(fn{f})(indx,:);     
    end
    muH = [muH(indx)];
end

if strcmp(sortVar , 'power')
    r = cell2mat(cellfun(@(z) max(z.^2) , ripples.detect.filtered , 'uniformoutput' , false)); 
    [~ , indx] = sort(r , sortDir);
    
end

if strcmp(sortVar , 'spikes')
        for f = 1 : length(fn)
        data.(fn{f}) = data.(fn{f})(indx,:);     
    end
    muH = [muH(indx)];
end

%% set up figure and axes

% 1 inch per 30 ms ripple
aspRat = 1250*30/1000;

fig = figure('units' , 'inches' , 'position' , [1 1 6 10] , ...
        'visible' , 'on' , 'name' , [ripples.expInfo.Subject ' ' num2str(ripples.expInfo.Date)] , 'KeyPressFcn' , @switchRip);

% axes for unfiltered trace
ax.unfiltered = axes('parent', fig , 'units' , 'inches' , 'position' , [1 6.5 diff(data.lfpIndx(1,:))/aspRat 1] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
hold on;
ax.unfiltered.YLabel.String = 'Raw Trace (uV)';

% Make scale bar..
scaleb = axes('parent' , fig , 'units' , 'inches' , 'position' , [1.25 6.4 15/aspRat 1] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'none' , 'XColor' , 'k' , 'XLim' , [0 15] , 'XTick' , [0:5:15] , 'XTicklabel' , {} , 'fontname' , 'arial' , 'fontsize' , 10); 
  scaleb.XLabel.String = '15 ms';
  
% axes for ripple filtered trace
ax.filtered = axes('parent', fig , 'units' , 'inches' , 'position' , [1 5 diff(data.lfpIndx(1,:))/aspRat 1] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
hold on;
ax.filtered.YLabel.String = 'Ripple Band (z)';

% axes for envelope
% ax.envelope = axes('parent', fig , 'units' , 'inches' , 'position' , [1 3.5 diff(data.lfpIndx(1,:))/aspRat 1] , 'box' , 'off' , ...
%     'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
% hold on; 
% 
% % axes for zMua
ax.zMua = axes('parent', fig , 'units' , 'inches' , 'position' , [1 3.5 diff(data.lfpIndx(1,:))/aspRat 1] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
hold on; 
ax.zMua.YLabel.String = 'Multi-Unit Firing (z)';

% axes for rastor plot
axSpkt = axes('parent', fig , 'units' , 'inches' , 'position' , [1 2 diff(data.lfpIndx(1,:))/aspRat 1] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
hold on; 
axSpkt.YLabel.String = '# MU Spikes';

% find ylims for each type of plot
if n
    fn = fieldnames(ax)
    for f = 1 : length(fn)
        d = data.(fn{f});
        ma = max(cell2mat(cellfun(@(z) max(z) , d , 'uniformoutput' , false)));
        mi = min(cell2mat(cellfun(@(z) min(z) , d , 'uniformoutput' , false)));
        di = ma - mi;
        ylimz.(fn{f}) = [mi - 0.05 * di , ma + 0.05 * di];
    end
end
makePlots;



function currentRip = switchRip(a , b)
global ax data aspRat currentRip axSpkt

if strcmp(b.Key , 'leftarrow') & currentRip > 1
    currentRip = currentRip - 1;
end

if strcmp(b.Key , 'rightarrow') & currentRip < size(data.lfpIndx , 1)
    currentRip = currentRip + 1;
end

fn = fieldnames(ax);
for f = 1 : length(fn)
    c = get(ax.(fn{f}) , 'children');
    for cc = 1 : length(c)
        delete(c(cc));
    end
end

    c = get(axSpkt , 'children');
    for cc = 1 : length(c)
        delete(c(cc));
    end

makePlots;%(ax , data , currentRip , aspRat);

function makePlots
global ax data aspRat currentRip n ylimz indx muRange muH axSpkt;
fn = fieldnames(ax);
for f = 1 : length(fn)
    d = data.(fn{f}){currentRip};
    L = logical(data.ripLog{currentRip});
    xval = 1 : length(d);
    plot(ax.(fn{f}) , xval , d , 'linestyle' , '-' , 'color' , [0.4 0.4 0.4] , 'linewidth' , 0.25 , 'marker' , 'none');
    plot(ax.(fn{f}) , xval(L) , d(L) , 'linestyle' , '-' , 'color' , 'k' , 'linewidth' , 0.5 , 'marker' , 'none');
    ax.(fn{f}).XLim = [0 , length(d)];
    ax.(fn{f}).Position(3) = diff(data.lfpIndx(currentRip,:))/aspRat;
    
    if strcmp(fn{f} , 'filtered')
        d = data.envelope{currentRip};
     
            p = plot(ax.(fn{f}) , xval(L) , d(L) , 'linestyle' , '-' , 'color' , [1 0.1 0.1]  , 'linewidth' , 1 , 'marker' , 'none');
            uistack(p,'bottom');
               p = plot(ax.(fn{f}) , xval , d , 'linestyle' , '-' , 'color' , [1 0.4 0.4] , 'linewidth' , 0.25 , 'marker' , 'none');
               uistack(p,'bottom');
    end
    if n
        ax.(fn{f}).YLim = ylimz.(fn{f});
    end
    
    if f == 1
        ax.(fn{f}).Title.String = [num2str(currentRip) ' ' num2str(indx(currentRip))];
    end
end

bar(axSpkt , xval , muH{currentRip} , 1 , 'facecolor' , 'k' , 'linestyle' , 'none');
plot(axSpkt , [repmat(find(diff(data.ripLog{currentRip}) == 1)+1,1,2)] , axSpkt.YLim , 'color' , 'r' , 'linestyle' , ':' , 'linewidth' , 0.75);
plot(axSpkt , [repmat(find(diff(data.ripLog{currentRip}) == -1),1,2)] , axSpkt.YLim , 'color' , 'r' , 'linestyle' , ':' , 'linewidth' , 0.75);
c = sum(data.spkT{currentRip} >= 0 & data.spkT{currentRip} < sum(data.ripLog{currentRip})/1250);
text(axSpkt , find(diff(data.ripLog{currentRip}) == -1) , axSpkt.YLim(2) , num2str(c) , 'color' , 'b' , 'fontname' , 'arial' , 'fontsize' , 10 , 'horizontalalignment' , 'right');
axSpkt.Position(3) = diff(data.lfpIndx(currentRip,:))/aspRat;
%zMua plot
% ax.mua.zMua = 

% fn = fieldnames(ax.mua)
% for f = 1 : length(fn)
% ax.mua.(fn{f}).Position(3) = diff(data.lfpIndx(currentRip,:))/aspRat;
% end
