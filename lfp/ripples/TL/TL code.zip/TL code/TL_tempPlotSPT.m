function TL_tempPlotSPT(data)

F = figure('units' , 'inches' , 'position' , [1 0.5  8 3] , 'visible' , 'on');
set( F, 'Renderer' , 'opengl');
ax.preference = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 0.5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1.0] , 'XLim' , [0 1.0] , 'XTick' , [0 : 0.25 : 1.0]);
hold on;
ax.preference.YLabel.String = 'Cumulative Fraction';
ax.preference.XLabel.String = 'Sucrose Preference';

ax.suc = axes('parent' ,  F , 'units' , 'inches' , 'position' , [2.5 0.5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.25 2.5] , 'XTick' , []);
hold on;
ax.suc.YLabel.String = 'Sucrose Consumption (g)';

ax.water = axes('parent' ,  F , 'units' , 'inches' , 'position' , [4 0.5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.25 2.5] , 'XTick' , []);
hold on;
ax.water.YLabel.String = 'Water Consumption (g)';

ax.totVol = axes('parent' ,  F , 'units' , 'inches' , 'position' , [5.5 0.5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.25 2.5] , 'XTick' , []);
hold on;
ax.totVol.YLabel.String = 'Total Consumption (g)';

cols = {[0.2 0.2 0.2] , 'c'};
ug = unique(data.gen);
for u = 1 : length(ug)
    i = data.gen == ug(u);
    s = sort(data.suc(i) ./ (data.suc(i) + data.water(i)) , 'ascend');
    x = [1:length(s)]/length(s);
    plot(ax.preference , s , x , 'linestyle' , '-' , 'color' , cols{u} , 'marker' , 'o' , 'markersize' , 3 , ...
        'markerfacecolor' , cols{u} , 'markeredgecolor' , cols{u} , 'linewidth' , 0.75);
    text(ax.preference , 1 , 1 - 0.1*(u-1) , data.genLabel{u} , 'fontname' , 'arial' , 'color' , cols{u} , 'fontsize' , 8 , 'horizontalalignment' , 'left');

      jit = (rand(sum(i),1) - 0.5)/2
    bar(ax.water , u , mean(data.water(i,:)) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.25);
plot(ax.water, u*ones(sum(i),1) + jit , data.water(i,:) , 'linestyle' , 'none' , 'marker', 'o' , 'markersize' , 5 , 'markeredgecolor' , cols{u} , ...
    'markerfacecolor' , 'none');

      jit = (rand(sum(i),1) - 0.5)/2;
      bar(ax.suc , u , mean(data.suc(i,:)) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.25);
plot(ax.suc , u*ones(sum(i),1) + jit , data.suc(i,:) , 'linestyle' , 'none' , 'marker', 'o' , 'markersize' , 5 , 'markeredgecolor' , cols{u} , ...
    'markerfacecolor' , 'none');

    bar(ax.totVol , u , mean(data.suc(i,:)) + mean(data.water(i,:)) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.25);
plot(ax.totVol , u*ones(sum(i),1) + jit , data.suc(i,:) + data.water(i,:) , 'linestyle' , 'none' , 'marker', 'o' , 'markersize' , 5 , 'markeredgecolor' , cols{u} , ...
    'markerfacecolor' , 'none');
end

mx = max([ax.water.YLim , ax.suc.YLim]);
ax.water.YLim(2) = mx; ax.suc.YLim(2) = mx; clear mx;
