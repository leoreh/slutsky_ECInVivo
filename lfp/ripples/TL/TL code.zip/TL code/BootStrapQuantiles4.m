function [BSresults] = BootStrapQuantiles4(sampledata, dim, quantile_levels)
% BootStrapQuantiles.  This function uses bootstrapping to calculate quantiles of 
% sampledata with confidence intervals.  sampledata is an array (m x n).  One
% dimension is repeated, independent experimental samples (over which to calculate
% quantiles);  the other is different conditions.  dim specifies the conditions
% dimension. 
% quantile_levels is vector specifying quantiles to analyze, e.g. [.25 .5 .75]
% Output:  BSresults structure reports each bootstrapped quantile+-68%CI (using
%   a parametric model across bootstrap iterations), and, separately, quantile+-68%
%   CI using a non-parametric model.  68% CI is equivalent to one SEM:  when two 68%CI
%   error bars are non-overlapping, it corresponds to 95% confidence that the two medians
%   are different.  Each quantile is reported separately with fields:
%       BSresults.qNN.value 
%       BSresults.qNN.CI      % 68%CI, which is equivalent to 1 SEM.  This makes sense to display
                              % because nonoverlapping error bars would mean 2 sem difference, which
                              % is 95% confidence that the two means are different.
%       BSresults.qNN.CIminus   % value - CI
%       BSresults.qNN.CIplus    % value + CI
%       BSresults.qNN.nparCIminus  % value - nonparametric 68% CI
%       BSresults.qNN.nparCIplus   % value + nonparametric 68% CI
%   Each field is a vector with one entry for each element in the conditions dimension.

% DF Aug 11 2016

numiterations = 1000;

% replace any infs with NaNs, they will be ignored for the quantification
infs = find(isinf(sampledata));
for p = 1:length(infs)
   sampledata(infs(p))=NaN; 
end

if (numel(quantile_levels)==0)
    qlist = [0.25 0.5 0.75];    % quantiles to calculate
else
    qlist = quantile_levels;
end

sz = size(sampledata);
% fprintf('size of sampledata = %d by %d\n',sz(1), sz(2));

npts = sz(dim);     % number of points to independently analyze

if (dim == 2)
    sampledata = sampledata';
end

for pt = 1:npts
    
    samplesize = numel(sampledata(pt,:));
    BSsampledata = zeros(samplesize,1);
    BSquant = zeros(numiterations,length(qlist));
    
    for itr = 1:numiterations
        % populate single sample by drawing from sampledata with replacement
        for sample = 1:samplesize
            BSsampledata(sample)=sampledata(pt,randi(samplesize));
        end
        % measure quantiles for this iteration
        BSquant(itr,:) = quantile(BSsampledata, qlist);
    end
    
    % Bootstrap results
    ts = tinv([0.025  0.975],numiterations-1);       % T-Score for 2.5% and 97.5% of nml distrib with this deg of freedom
    for qt = 1:length(qlist)
        name = ['q' num2str(qlist(qt)*100)];
        % parametric CI
        SEM = nanstd(BSquant(:,qt));        % Calculating from sample population measures,
                                            %  not orig data points, so don't divide by sqrt(itr).
        BSresults.(name).value(pt) = nanmean(BSquant(:,qt));
        BSresults.(name).CI(pt) = SEM;     % +-1 SEM gives 84% confidence of mean, from parametric assumptions            
        BSresults.(name).CIminus(pt) = BSresults.(name).value(pt) - BSresults.(name).CI(pt);      
        BSresults.(name).CIplus(pt) = BSresults.(name).value(pt) + BSresults.(name).CI(pt);       
        % nonparametric CI
        npar=quantile(BSquant(:,qt),[.159 .5 .841]);     % nonparametric 68% CI, which is equiv to +- 1 SEM
%         npar=quantile(BSquant(:,qt),[.024 .5 .976]);     % nonparametric 95% CI, which is equiv to +- 1 SEM
        BSresults.(name).nparCIminus(pt)=npar(1);
        BSresults.(name).nparCIplus(pt)=npar(3);
        
    end % each quantile level
    
end % each pt to analyze

end % function

