function TL_scoreBehavior_v2(dur , varargin)

F = figure('units' , 'inches' , 'Position' , [7, 0.5 , 3 , 3] , ...
    'WindowKeyPressFcn' , @press , 'WindowKeyReleaseFcn' , @release , 'visible' , 'on');

data.funStart = [];
data.funEnd = [];
data.fi = [];
data.st = [];
data.key = [];
data.flag = 0;

guidata(F , data);

yeehawButt = uicontrol('parent' , F , 'style' , 'pushbutton' , ...
    'units' , 'inches' , 'position' , [0.025 0.025  , 2.95 , 1.4625] , ...
    'fontname' , 'arial' , 'fontsize' , 10 , 'String' , 'Yee-haw!!!');
%     'ButtonDownFcn' , @yeehaw);
% set(yeehawButt , 'callback' , {@yeehaw , yeehawButt});
nellieButt = uicontrol('parent' , F , 'style' , 'pushbutton' , ...
    'units' , 'inches' , 'position' , [0.025 1.5125  , 2.95 , 1.4625] , ...
    'fontname' , 'arial' , 'fontsize' , 10 , 'String' , 'Cool it, Nellie' , ...
    'enable' , 'off');

yeehawButt.ButtonDownFcn = {@yeehaw , nellieButt};
nellieButt.ButtonDownFcn = {@nellie ,  yeehawButt , dur};

function yeehaw(src , e , nellieButt)
set(src , 'enable' , 'off');
set(nellieButt , 'enable' , 'on');
data = guidata(src);
data.funStart = clock;
guidata(src,data);
return

function nellie(src , ~ , yeehawButt , dur)
set(src , 'enable' , 'off');
set(yeehawButt , 'enable' , 'on');
data = guidata(src);
data.funEnd = clock;
guidata(src,data)
makeGraph(data , dur);

function [fi , key] = release(src , e)
if ~strcmp(e.Key , 'space') & ~strcmp(e.Key , 'return')
    data = guidata(src);
    data.fi(end+1,:) = clock;
    data.flag = 0;
    guidata(src,data);
end
return

function [st , key] = press(src , e)
data = guidata(src);
if data.flag == 0 & ~strcmp(e.Key , 'space') & ~strcmp(e.Key , 'return')
    data.st(end+1,:) = clock;
    data.key(end+1) = str2num(e.Key);
    data.flag = 1;
    guidata(src,data);
end
if strcmp(e.Key , 'space')
    data.st = data.st(1:end-1,:);
    data.fi = data.fi(1:end-1,:);
    data.key = data.key(1:end-1);
    guidata(src,data);
end
return

function [st fi key] = makeGraph(data , dur)
totS = etime(data.funEnd , data.funStart);
epochSt = etime(data.st , data.funStart);
epochEnd = etime(data.fi , data.funStart);
epochDur = etime(data.fi , data.st);
epochType = data.key;
epochTypeNorm = nan(length(epochType),1);

uet = unique(epochType);
uetNorm = [1:length(uet)];
ylab = {};
for u = 1 : length(uet)
    ylab{u} = num2str(uet(u));
    epochTypeNorm(epochType == uet(u)) = uetNorm(u);
end

j = jet;
cols = j(floor(linspace(1,size(j,1),length(uet))),:)
F2 = figure('units' , 'inches' , 'Position' , [0.5 , 0.5 , 3 , 6]);

ax.epoch = axes('parent' ,  F2 , 'units' , 'inches' , 'position' , [0.5 0.5 2 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0 totS/60] , 'XTick' , [0:1:totS/60] , ...
    'YLim' , [0 , length(uet)+1] , 'YTick' , [1:1:length(uet)] , 'YTickLabel' , ylab);
hold on;
ax.epoch.XLabel.String = 'Minute';
for e = 1 : length(epochSt)
    c = cols(epochTypeNorm(e) , :); % TL ADD JITTER TO Y VALUE
    plot(ax.epoch , [epochSt(e) , epochEnd(e)]/60 , repmat(epochTypeNorm(e),1,2) + (rand(1)-0.5)/3 , 'marker' , 'o' , 'markersize' , 1 , ...
        'linestyle' , '-' , 'linewidth' , 1.25 , 'color' , c , ...
        'markerfacecolor' , c , 'markeredgecolor' , c);
end

ax.minPerc = axes('parent' ,  F2 , 'units' , 'inches' , 'position' , [0.5 3 2 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0 totS/60] , 'XTick' , [0:1:totS/60]);
%     'Xlim' , [0.5 dur] , 'XTick' , [1 : dur]);% , ...
%     'YLim' , [0 , 1] , 'YTick' , [0 : 0.25 : 1]);
hold on;
ax.minPerc.XLabel.String = 'Minute';

% convert epochs to not cross over minute marks so will be easy to
tempEpochSt = [];
tempEpochEnd = [];
tempTypeNorm = [];
for t = 1 : size(epochDur , 1)
    range = [epochSt(t)/60 , ceil(epochSt(t)/60) : ceil(epochEnd(t)/60)];
    if length(range) > 2
        range(end) = epochEnd(t)/60;
        for r = 1 : length(range) - 1
            tempEpochSt(end+1) = range(r);
            tempEpochEnd(end+1) = range(r+1);
            tempTypeNorm(end+1) = epochTypeNorm(t);
        end
    else
        tempEpochSt(end+1) = epochSt(t);
        tempEpochEnd(end+1) = epochEnd(t);
        tempTypeNorm(end+1) = epochTypeNorm(t);
    end
end

% now sum total values in each minute
n = unique(tempTypeNorm);
h = zeros(dur , length(n));

% cols = j(floor(linspace(1,size(j,1),length(n))),:)

for m = 1 : dur
    for nn = 1 : length(n)
        i = ceil(tempEpochSt/60) == m & tempTypeNorm == n(nn);
        h(m,nn) = sum(tempEpochEnd(i) - tempEpochSt(i));
    end
end
h = h / 60;

for nn = 1 : length(n)
    c = cols(nn,:)
    plot(ax.minPerc , [1:size(h,1)] , h(:,nn) , 'marker' , 'o' , 'markersize' , 1 , ...
        'linestyle' , '-' , 'linewidth' , 1.25 , 'color' , c , ...
        'markerfacecolor' , c , 'markeredgecolor' , c);
end

assignin('base' , 'data' , data);
a = input('Howdy, Pardner. Save data 2 struct? (1/0)');
if a == 1
    try
        subject = input('Subject name please (string)');
    catch
        subject = input('Typo!! Subject name please (string)');
    end
    try
        group = input('Group/Genotype please (string)');
    catch
        group = input('Typo!! Group/Genotype please (string)');
    end
    try
        legend = input('Legend for states please (cell array of strings)');
    catch
        legend = input('Typo!! Legend for states please (cell array of strings)');
    end
    try
        type = input('Test Name please (string)');
    catch
        type = input('Typo!! Test Name please (string)');
    end
    try
        dt = input('Date Please (integer, YYMMDD)');
    catch
        dt = input('Typo!! Date Please (integer, YYMMDD)');
    end
    pn = uigetdir;
    fn = [pn , filesep , 'cohortData.mat'];
    if isfile(fn)
        load(fn);
    else
        cohortData.Subject = [];
        cohortData.Type = [];
        cohortData.Date = [];
        cohortData.Group = [];
        cohortData.Legend = [];
        cohortData.starts = [];
        cohortData.ends = [];
        cohortData.val = [];
    end
    L = length({cohortData.Subject});
    cohortData(L+1).Subject = subject;
    cohortData(L+1).Type = type;
    cohortData(L+1).Group = group;
    cohortData(L+1).Legend = legend;
    cohortData(L+1).Date = dt;
    cohortData(L+1).starts = etime(data.st , data.funStart);
    cohortData(L+1).ends = etime(data.fi , data.funStart);
    cohortData(L+1).val = data.key; % TL may need to fix this..
    
    save([pn , filesep , 'cohortData.mat'] , 'cohortData');
end

