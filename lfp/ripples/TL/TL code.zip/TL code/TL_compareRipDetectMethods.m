function [detect] = TL_compareRipDetectMethods(pathname)

% fix pathname string
if ~strcmp(pathname(end) , filesep)
    pathname = [pathname , filesep];
end


sleep = TL_extractSleep(pathname);
currSleep = sleep([1 : 12*60*60]);

stateList = {'Active Wake', 'Quiet Wake' , 'Light Sleep' , 'NREM' , 'REM' , 'bin' , 'unknown'};
% [statecols] : Color code for each state in stateList
stateCols = [0.8 0 0; 1 0.25 0.25; 0.25 0.25 0.8; 0 0 0.8; 0.25 0.8 0.25; 0.4 0.4 0.4; 0.7 0.7 0.7];

methodCols = [0.1 0.1 0.1; 0.4 0.4 0.4; 0.7 0.7 0.7];

%% First check if 'best' ripple channels have been detected yet by calculating RMS
% If not, run TL_rippleBandRMS
% If so, load 'RMS.mat' from subject's path (eg. 'E:\refaela\wt2\')

f = strfind(pathname , filesep);
f = f(end-1);

subjPath = pathname(1:f); clear f;

d = dir([subjPath , '*beztRipChans*']);
if ~isempty(d)
    load([subjPath , filesep , 'beztRipChans.mat']);
else
    [beztRipChans] = TL_rippleBandRMS(subjPath , baseline , sleep , saveLFP , saveRMS);
end
clear subjPath;

% Now find best channel on each of the 4 tetrodes, and take the 3 best
% of these
allCh = [1:16];
ut = unique(beztRipChans.tet);
for t = 1 : length(ut)
    currCh = allCh(beztRipChans.tet == ut(t));
    [~ , r] = ismember(beztRipChans.rank , currCh);
    i = find(r>0);
    ripChans(t) = currCh(r(i(1)));
end
[~ , r] = ismember(beztRipChans.rank , ripChans);
i = find(r>0);
ripChans = ripChans(r(i(1:3)));

%% Load multi unit spike data
temp = dir(pathname);
fnames = {temp(~[temp.isdir]).name}';
clear temp;

temp = fnames{cell2mat(cellfun(@(z) ~isempty(strfind(z,'spktimes')) , fnames , 'uniformoutput' , false))};
muSpkSec = load([pathname , temp]);
[r,~] = find([1:4;5:8;9:12;13:16] == ripChans(1));

% some mu spike files refaela sent were as integer indices..others as
% time..so check format and convert to seconds if necessary
if sum(~rem(muSpkSec.spktimes{r},1)) == length(muSpkSec.spktimes{r})
    muSpkSec = muSpkSec.spktimes{r}/24414.06;
else
    muSpkSec = muSpkSec.spktimes{r};
end

%% Load LFP

for r = 1 : length(ripChans)
    lfp{r} = TL_getLFP('basepath' , pathname , 'ch' , ripChans(r) , 'fs' , 1250 , ...
        'extension' , 'lfp' , 'savevar' , true , 'forceL' , true , 'interval' , [0 12*60*60]);
end

lfp = cellfun(@(z) z.data , lfp , 'uniformoutput' , false);

%% Loop thru ripple methods


[d , ~] = TL_ripDetect_booneFoster2018(lfp , [3,0.75,5,20] , currSleep , muSpkSec);
detect.mua{1} = d;

[d , ~] = TL_ripDetect_booneFoster2018(lfp , [3,0.75,10,20] , currSleep , muSpkSec);
detect.mua{2} = d;

[d , ~] = TL_ripDetect_booneFoster2018(lfp , [3,0.75,15,20] , currSleep , muSpkSec);
detect.mua{3} = d;

% [d , ~] = TL_ripDetect_varelaWilson2020(lfp{1} , currSleep , muSpkSec);
% detect.mua{2} = d;
% 
% [d , ~] = TL_ripDetect_tomarMcHugh2020(lfp{1} , currSleep , muSpkSec);
% detect.mua{3} = d;

[d , ~] = TL_ripDetect_booneFoster2018(lfp , [3,0.75,10,20] , currSleep , []);
detect.nomua{1} = d;

[d , ~] = TL_ripDetect_booneFoster2018(lfp , [3,0.75,15,20] , currSleep , []);
detect.nomua{2} = d;

[d , ~] = TL_ripDetect_booneFoster2018(lfp , [3,0.75,20,20] , currSleep , []);
detect.nomua{3} = d;
% 
% [d , ~] = TL_ripDetect_varelaWilson2020(lfp{1} , currSleep , []);
% detect.nomua{2} = d;
% 
% [d , ~] = TL_ripDetect_tomarMcHugh2020(lfp{1} , currSleep , []);
% detect.nomua{3} = d;

%% Add peak position and peak power of each ripple

fields = {'mua' , 'nomua'};
% Construct coefficients for butterworth bandpass filter
[c1 c2] = butter(5,[80 250]/(1250/2),'bandpass');

for f = 1 : length(fields)
    for ff = 1 : length(detect.(fields{f}))
        D = detect.(fields{f}){ff}.lfpIndx;
        L = lfp{ff};
        fL = filtfilt(c1,c2,double(L));
        fL2 = fL.^2;
        peakPosition = nan(size(D , 1) , 1);
        peakPower = nan(size(peakPosition));
        for d = 1 : length(peakPower)
            [m , i] = max(fL2(D(d,1):D(d,2)));
            peakPosition(d) = i + D(d,1) - 1;
            peakPower(d) = m;
        end
        detect.(fields{f}){ff}.peakPosition = peakPosition;
        detect.(fields{f}){ff}.peakPower = peakPower;
        clear peakPosition peakPower;
    end
end

%%

fields = {'mua' , 'nomua'};
sh = [-0.33 0 0.33];
for f = 1 : length(fields)
    
    F = figure('units' , 'inches' , 'position' , [0.5 , 0.5 , 10 ,  3] , 'PaperPosition' , [0, 0 , 12 ,  8] , ...
        'Name' , 'Control Panel' ,'Tag' , 'control_panel' , 'visible' , 'on');
    set(F , 'renderer' , 'opengl');
    
            % Rate of ripples in awake , NREM and REM
        ax.rate = axes('parent' , F , 'units' , 'inches' , 'position' , [1 1 1.5 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
        hold on;
        ax.rate.XLim = [0.25 length(stateList) + 0.75];
        ax.rate.YLabel.String = 'Ripple Occurrence (Hz)';
        
        % MU firing per NREM ripple
                ax.muHz = axes('parent' , F , 'units' , 'inches' , 'position' , [3 , 1 , 1.5 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 10);
        hold on;
        ax.muHz.YLim = [0 1];
        ax.muHz.YLabel.String = 'Cumulative Fraction';
        ax.muHz.XLabel.String = 'MU Firing Rate (Hz)';  
        
                % Ms duration per NREM ripple
                ax.dur = axes('parent' , F , 'units' , 'inches' , 'position' , [5 , 1 , 1.5 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 10);
        hold on;
        ax.dur.YLim = [0 1];
        ax.dur.YLabel.String = 'Cumulative Fraction';
        ax.dur.XLabel.String = 'Duration (ms)';
        
                        % Power per NREM ripple
                ax.pow = axes('parent' , F , 'units' , 'inches' , 'position' , [7 , 1 , 1.5 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 10);
        hold on;
        ax.pow.YLim = [0 1];
        ax.pow.YLabel.String = 'Cumulative Fraction';
        ax.pow.XLabel.String = 'Power';
        
                                % Fraction Ripples with MUA burst
                ax.muaFrac = axes('parent' , F , 'units' , 'inches' , 'position' , [9 , 1 , 1.5 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 10);
        hold on;
        ax.muaFrac.YLim = [0 1];
        ax.muaFrac.YLabel.String = 'Fraction of Ripples with MUA Burst';

        for a = 1 : length(detect.(fields{f}))
            
            % Rate of ripples in awake , NREM and REM
            pPos = floor(detect.(fields{f}){a}.peakPosition/1250) + 1;
            sL = currSleep(pPos);
            [h1] = histcounts(sL , [1 : length(stateList) + 1]);
            [h2] = histcounts(currSleep , [1 : length(stateList) + 1]);
            ripHz = h1 ./ h2;
            barWi = 1/length(detect.(fields{f}));
            for b = 1 : length(stateList)
                bar(ax.rate , b+sh(a) , ripHz(b) , barWi , 'facecolor' , stateCols(b,:) , 'edgecolor' , methodCols(a,:) , 'linewidth' , 1);
            end
            
            % MU firing per NREM ripple (distribution)
            Li = detect.(fields{f}){a}.lfpIndx;
            i = find(currSleep(pPos) == find(strcmp(stateList , 'NREM')));
            muHz = nan(length(i) , 1);
            for ii = 1 : length(i)
                muHz(ii) = sum(muSpkSec >= Li(i(ii) , 1)/1250 & muSpkSec < Li(i(ii) , 2)/1250)/((Li(i(ii) , 2) - Li(i(ii) , 1))/1250);
            end
            muHz = sort(muHz , 'ascend');
            ypos = [0:length(muHz)]/length(muHz);
            plot(ax.muHz , [0; muHz] , ypos , 'linestyle' , '-' , 'color' , methodCols(a,:) , 'marker' , 'none' , 'linewidth' , 1.5);
            
            % Ms duration per NREM ripple
            dur = 1000 * (Li(i,2) - Li(i,1))/1250;
            dur = sort(dur , 'ascend');
            plot(ax.dur , [0; dur] , ypos , 'linestyle' , '-' , 'color' , methodCols(a,:) , 'marker' , 'none' , 'linewidth' , 1.5);
            
            % Power per NREM ripple
            pow = detect.(fields{f}){a}.peakPower(i);
            pow = sort(pow , 'ascend');
            plot(ax.pow , [0; pow] , ypos , 'linestyle' , '-' , 'color' , methodCols(a,:) , 'marker' , 'none' , 'linewidth' , 1.5);
            
            % Ripples with MUA burst
            frac = sum(currSleep(floor(detect.mua{a}.peakPosition/1250) + 1) == find(strcmp(stateList , 'NREM'))) / length(i);
            bar(ax.muaFrac , a , frac , 1 , 'facecolor' , methodCols(a,:) , 'edgecolor' , methodCols(a,:) , 'linewidth' , 1);
        end    
    
end

