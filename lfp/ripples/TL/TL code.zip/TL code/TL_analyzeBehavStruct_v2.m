function TL_analyzeBehavStruct_v2(cohortData , behavior)

% v2 works on cohortData metastructure output from TL_scoreBehvaior_v3

% -------------------------------------------------------------------------
grpList = {cohortData.Group};
ug = unique(grpList);
% Kludge because display order is not in alphabetical order..figure this
% out later (maybe thru excel spreadsheet)
if length(ug) == 4
    ug = {'Control' , 'FST' , 'Isolated' , 'FST Isolated'};
end
behavList = {cohortData.Behavior};

allCols = {'k' , [0.0 0.7 0.7] , [0.4 0.4 0.4] , 'c'};
useCols = [allCols(1:length(ug))];

if strcmp(behavior , 'fst')
    
    % need to do separately fst1 and fst2 and if both exist do a third
    % figure/column with the joint data
end

if ~isempty(strfind(behavior , 'plash'))
    iSplash = cellfun(@(z) ~isempty(strfind(z , 'plash')) , behavList);
    
    % set up axes and figures ---------------------------------------------
    F = figure('units' , 'inches' , 'Position' , [0.5, 0.5 , 10 , 9]);
    
    ax.Irearing = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 5 1.0 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.75 , 5.0] , 'XTick' , [0:1:5.0] , 'TickLength' , [0 0]);
    hold on;
    ax.Irearing.YLabel.String = ['Rearing Events per Minute'];
    ax.Irearing.XLabel.String = ['Minute'];
    
    ax.Idigging = axes('parent' ,  F , 'units' , 'inches' , 'position' , [2.0 5 1.0 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.75 5.0] , 'XTick' , [0:1:5.0] ,  'TickLength' , [0 0]);
    hold on;
    ax.Idigging.YLabel.String = ['Digging Events per Minute'];
    ax.Idigging.XLabel.String = ['Minute'];
    
    ax.ItotExplor = axes('parent' ,  F , 'units' , 'inches' , 'position' , [3.5 5 1.0 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.75 5.0] , 'XTick' , [0:1:5.0] ,  'TickLength' , [0 0]);
    hold on;
    ax.ItotExplor.YLabel.String = ['Total Exploratory Events per Minute'];
    ax.ItotExplor.XLabel.String = ['Minute'];
    
    ax.barEventRateMean = axes('parent' , F , 'units' , 'inches' , 'position' , [5 5 0.5 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.25 length(ug) + 0.5] , 'TickLength' , [0 0]);
    hold on;
    ax.barEventRateMean.YLabel.String = 'Total Exploratory Events per Minute';
    ax.barEventRateMean.XColor = 'none';
    
    ax.barEventRatePeak = axes('parent' , F , 'units' , 'inches' , 'position' , [6 5 0.5 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.25 length(ug) + 0.5] , 'TickLength' , [0 0]);
    hold on;
    ax.barEventRatePeak.YLabel.String = 'Peak Total Exploratory Events per Minute';
    
    ax.barShakesMean = axes('parent' , F , 'units' , 'inches' , 'position' , [0.5 3.5 0.5 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.25 length(ug) + 0.5] , 'TickLength' , [0 0]);
    hold on;
    ax.barShakesMean.YLabel.String = '# Shakes Per Minute';
    
    ax.Igrooming = axes('parent' ,  F , 'units' , 'inches' , 'position' , [1.5 3.5 1.0 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.5 5] , 'XTick' , [1:5] ,  'TickLength' , [0 0]);
    hold on;
    ax.Igrooming.YLabel.String = 'Grooming Time (s)';
    ax.Igrooming.XLabel.String = 'Minute';
    
    ax.grooming = axes('parent' ,  F , 'units' , 'inches' , 'position' , [3 3.5 1.0 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.5 5] , 'XTick' , [1:5] ,  'TickLength' , [0 0]);
    hold on;
    ax.grooming.YLabel.String = 'Grooming Time (s)';
    ax.grooming.XLabel.String = 'Minute';
    
    ax.barGroomingMean = axes('parent' , F , 'units' , 'inches' , 'position' , [4.5 3.5 0.5 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.25 length(ug) + 0.5] , 'TickLength' , [0 0]);
    hold on;
    ax.barGroomingMean.YLabel.String = 'Grooming (s/min)';
    
    ax.barGroomingPeak = axes('parent' , F , 'units' , 'inches' , 'position' , [5.5 3.5 0.5 1.0] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.25 length(ug) + 0.5] , 'TickLength' , [0 0]);
    hold on;
    ax.barGroomingPeak.YLabel.String = 'Peak Grooming (s/30s)';
    
        ax.scatSubj = axes('parent' , F , 'units' , 'inches' , 'position' , [2 0.5 1.5 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'TickDir' , 'out' , 'XLim' , [0 1] , 'YLim' , [0 80]);
    hold on;
    ax.scatSubj.YLabel.String = 'Exploratory Events Per Minute';
    ax.scatSubj.XLabel.String = 'Fraction of Time Grooming';
    % ---------------------------------------------------------------------
    
    % Plot summed grooming time over time per mouse
    for u = 1 : length(ug)
        i = find(cellfun(@(z) strcmp(z , ug{u}) , grpList) & iSplash);
        latency{u} = [];
        
        % Calculate number of events for each val
%         nEvents = cellfun(@(z) histcounts(z) , {cohortData(i).val} , 'uniformoutput' , false);
        
        % Calculate 30 second sliding window sum events for each val (events per
        % minute) and eventRollSec
        eventRollRate = [];
        eventRollSec = [];
        for ii = 1 : length(i)
            row = i(ii);
            
            % Calculate rolling rate of discrete events (eg. shakes,
            % rearing, digging)
            uv = cohortData(row).Key;%(logical(cohortData(row).Discrete));
            
            dur = [];
            for v = 1 : length(uv)
                val = uv(v);
                ts = cohortData(row).starts(cohortData(row).val == val);
                te = cohortData(row).ends(cohortData(row).val == val);
                dur = te - ts;
                for s = 0 : 4.5*60
                    inc = ts >= s & ts < s + 30;
                    eventRollRate(ii,v,s+1) = 2*sum(inc);
                    clear inc;
                end
                clear dur ts te val;
            end
            clear uv dur;
        
        
        % Calculate rolling time (sec) of non discrete events (eg grooming
        % types)
        uv = cohortData(row).Key;%(~logical(cohortData(row).Discrete));
        dur = [];
        for v = 1 : length(uv)
            val = uv(v);
            ts = cohortData(row).starts(cohortData(row).val == val);
            te = cohortData(row).ends(cohortData(row).val == val);
            dur = te - ts;
            for s = 0 : 4.5*60
                inc = ts >= s & ts < s + 30;
                if sum(inc) > 0
                    if  te(find(inc,1,'last')) < s + 30
                        eventRollSec(ii,v,s+1) = sum(dur(inc));
                    else
                        finc = find(inc);
                        if sum(inc) > 1
                            eventRollSec(ii,v,s+1) = sum(dur(finc(1:end-1))) + dur(finc(end)) - (te(finc(end)) - (s + 30));
                        else
                            eventRollSec(ii,v,s+1) = dur(finc) - (te(inc) - (s + 30));
                        end
                    end
                else
                    eventRollSec(ii,v,s+1) = 0;
                end
                if eventRollSec(ii,v,s+1) < 0
                    x=1;
                end
              
            end
        end
end
        % Calculate duration and count of each event per nonoverlapping 30
        % second intervals (10 intervals per 5 minutes)
        intervalz = [0:30:5*60];
        
        for ii = 1 : length(i)
            % convert epochs to not cross over minute marks so will be easy to
            tSt = [];
            tEnd = [];
            tVal = [];
            st = cohortData(i(ii)).starts;
            ed = cohortData(i(ii)).ends;
            val = cohortData(i(ii)).val;
            
            % clear times past 5 minutes
            keep = st <= 5*60
            st = st(keep); ed = ed(keep); val = val(keep);
            ed(ed > 5*60) = 5*60;
            % Easiest is to divide all the times by 30, add 1 to get
            % intervalz index
            stnorm = st / 30;
            ednorm = ed / 30;
%             for t = 1 : size(st , 1)
            stflo = floor(stnorm);
            edflo = floor(ednorm);
            uneq = find(edflo > stflo);
            for t = 1 : size(st , 1)
                if ismember(t , uneq)
                    range = st(t) : 30 : ed(t); if range(end) ~= ed(t), range(end+1) = ed(t); end
                    for r = 1 : length(range) - 1
                        tSt(end + 1) = range(r);
                        tEnd(end + 1) = range(r+1);
                        tVal(end + 1) = val(t);
                    end
                else
                    tSt(end+1) = st(t);
                    tEnd(end+1) = ed(t);
                    tVal(end+1) = val(t);
                end
            end

            uv = unique(tVal);
            for uuv = 1 : length(uv)
                iii1 = tVal == uv(uuv);
                for hh = 1 : length(intervalz) - 1
                    iii = iii1 & tSt >= intervalz(hh) & tEnd <= intervalz(hh+1);
                    h30s{u}(uuv,ii,hh) = sum(tEnd(iii) - tSt(iii));
                    nEvents{u}(uuv,ii,hh) = sum(iii);
                end
            end
        end
        
        % assumes same legend for each subject.
        fn = cohortData(i(1)).Legend;
        odds = [1:2:10]; evens = [2:2:10]
        temp = cellfun(@(z) strfind(z , 'ear') , fn , 'uniformoutput' , false);
        iRear = find(cellfun(@(z) ~isempty(z) , temp));
        rearing = squeeze(nEvents{u}(iRear , : , :));
        plot(ax.Irearing , [1:5] , rearing(:,odds) + rearing(:,evens) , 'color' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 0.5 , 'marker' , 'none');

                temp = cellfun(@(z) strfind(z , 'ig') , fn , 'uniformoutput' , false);
        iDig = find(cellfun(@(z) ~isempty(z) , temp));
        digging = squeeze(nEvents{u}(iDig , : , :));
%         jit = rand([1,size(rearing)]) - 0.5 / 5;
        plot(ax.Idigging , [1:5] , digging(:,odds) + digging(:,evens) , 'color' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 0.5 , 'marker' , 'none');
        
        rd = rearing + digging;
        p = plot(ax.ItotExplor , [1:5] , rd(:,odds) + rd(:,evens) , 'color' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 0.5 , 'marker' , 'none');
        %     p(:).Color(4) = 0.5;
        
        jit = (rand([1,size(rearing,1)]) - 0.5)/3
        data = sum(sum(nEvents{u}([iRear , iDig] , : , :) , 1) , 3) / 5;
%         data = cellfun(@(z) sum(z([iRear , iDig]))/5 , nEvents{u});
        mn = mean(data);
        bar(ax.barEventRateMean , u , mn , 0.9 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linewidth' , 0.5 , 'linestyle' , '-');
        plot(ax.barEventRateMean , u+jit , data , 'linestyle' , 'none' ,'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        
        data = max(squeeze(sum(eventRollRate(: , [iRear , iDig] , :) , 2)) , [] , 2);
        mn = mean(data);
        bar(ax.barEventRatePeak , u , mn , 0.9 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linewidth' , 0.5 , 'linestyle' , '-');
        plot(ax.barEventRatePeak , u+jit , data , 'linestyle' , 'none' ,'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        
        temp = cellfun(@(z) strfind(z , 'hake') , fn , 'uniformoutput' , false);
        iShake = find(cellfun(@(z) ~isempty(z) , temp));
        data = sum(sum(nEvents{u}(iShake , : , :) , 1) , 3) / 5;
        mn = mean(data);
        bar(ax.barShakesMean , u , mn , 0.9 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linewidth' , 0.5 , 'linestyle' , '-');
        plot(ax.barShakesMean , u+jit , data , 'linestyle' , 'none' ,'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        
        
        % grooming = squeeze(sum(eventRollSec(: , iGroom , :),2));
        % plot(ax.grooming , [0:size(grooming,2)-1]/60 , grooming , 'color' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 0.5 , 'marker' , 'none');
        
        iGroom = cellfun(@(z) ~isempty(strfind(z , 'ack')) | ~isempty(strfind(z , 'ead')) , fn);
        
        totalGroom = squeeze(sum([h30s{u}(iGroom , : , :)] , 1));
        totalGroom = totalGroom(: , odds) + totalGroom(: , evens);
        ttg = sum(totalGroom , 2);
        mngroomData = mean(totalGroom , 1);
        segroomData = std(totalGroom , 1)/sqrt(size(totalGroom , 1));
        
        % Plot individual grooming traces, minute by minute
        for s = 1 : size(totalGroom , 1)
            plot(ax.Igrooming , [1:5] , totalGroom(s , :) , 'color' , useCols{u} , 'linewidth' , 0.5 , 'linestyle' , '-');% , ...
%                 'marker' , 'o' , 'markersize' , 3 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        end
        
        % Plot mean/se grooming traces, minute by minute
        plot(ax.grooming , [1:5] , mngroomData , 'color' , useCols{u} , ...
            'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        for s = 1 : length(segroomData)
            plot(ax.grooming  , [s , s] , [mngroomData(s) - segroomData(s) , mngroomData(s) + segroomData(s)] , 'color' , useCols{u} , ...
                'marker' , 'none' , 'linewidth' , 0.75 , 'linestyle' , '-');
        end
        
        % Bar mean grooming time per minute
        data = mean(totalGroom , 2);
        mn = mean(data);
        bar(ax.barGroomingMean , u , mn , 0.9 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linewidth' , 0.5 , 'linestyle' , '-');
        plot(ax.barGroomingMean , u+jit , data , 'linestyle' , 'none' ,'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        
        % Bar peak Back grooming time per minute
%         iBack =  cellfun(@(z) ~isempty(strfind(z , 'ack')) , fn);
        data = squeeze(sum(eventRollSec(: , iGroom , :) , 2));
        mx = max(data,[],2);
        mn = mean(mx);
        bar(ax.barGroomingPeak , u , mn , 0.9 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linewidth' , 0.5 , 'linestyle' , '-');
        plot(ax.barGroomingPeak , u+jit ,mx , 'linestyle' , 'none' ,'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        
                % Scatter of grooming x exploratory behavior (to see if the mice
        % are always doing something at least..)
        % Extract all values in eventrollrate and eventrollsec ans scatter
        % them
        temp = sum(sum(nEvents{u}([iRear , iDig] , : , :),1),3)/5;
        yval = reshape(temp , 1 , prod(size(temp)));
        yjit = (rand(1,prod(size(temp)))-0.5)/2;
        yval = yval + yjit; yval(yval<0) = 0;
        temp = sum(sum(h30s{u}(iGroom , : , :),1),3)/300;
        xval = reshape(temp , 1 , prod(size(temp)));
        scatter(ax.scatSubj , xval , yval , 10 , 'marker' , 'o'  , 'linewidth' , 3 , 'markerfacecolor' , 'none' , 'markeredgecolor' , useCols{u} , 'markerfacealpha' , 0.5 , 'markeredgealpha' , 0.5);

        % Plot separate scatter using rolling data for each individual
        % Add histograms to the x and y axes to see global shifts
       allaxpos = [repmat([0.5; 2.5; 4.5], 3 , 1) , [repmat(5,3,1);repmat(3,3,1);repmat(1,3,1)]]
        Findiv{u} = figure('units' , 'inches' , 'Position' , [0.25+((u-1)*6), 0.25 , 6 , 7]);
              xbins = [0:0.05:1];
        ybins = [0:3:100];
        for ii = 1 : length(i)
       
         yval = squeeze(sum(eventRollRate(ii , [iRear , iDig] , :),2)/0.5);
        xval = squeeze(sum(eventRollSec(ii , iGroom , :),2))/30;
        yjit = (rand(1,prod(size(yval)))-0.5)*2;
         axI{u}{ii} = axes('parent' , Findiv{u} , 'units' , 'inches' , 'position' , [allaxpos(ii,:) , 1 , 1] , 'box' , 'off' , ...
                    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'TickDir' , 'out');
    hold on;
    axI{u}{ii}.YLabel.String = 'Exploratory Events Per Minute';
    axI{u}{ii}.XLabel.String = 'Fraction of Time Grooming';
    % scatter individually so time is plotted as well
    for s = 1 : length(xval)
        scatter(axI{u}{ii} , xval(s) , yval(s)+yjit(s) , 3 , 'marker' , 'o'  , 'linewidth' , 1 , ...
            'markerfacecolor' , 'none' , 'markeredgecolor' , [s/length(xval) , 0 , 1-(s/length(xval))] , 'markerfacealpha' , 0.5 , 'markeredgealpha' , 0.5);
    end
%         scatter(axI{u}{ii} , xval , yval+yjit' , 3 , 'marker' , 'o'  , 'linewidth' , 1 , 'markerfacecolor' , 'none' , 'markeredgecolor' , useCols{u} , 'markerfacealpha' , 0.5 , 'markeredgealpha' , 0.5);
        
        xh = histcounts(xval , xbins);
        xh = xh/sum(xh);
        axxh = axes('parent' , Findiv{u} , 'units' , 'inches' , 'position' , [allaxpos(ii,:) + [0 , 1.05] , max(xval) , 0.25] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'none' , 'linewidth' , 0.25 , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
            'TickDir' , 'out' , 'YLim' , [0 max(xh)] , 'XLim' , [0 max(xval)] , 'YTick' , 1 , 'YTickLabel' , '');
        hold on;
        bar(axxh , xbins(1:end-1) , xh , 1 , 'facecolor' , useCols{u} , 'linestyle' , 'none');
        
        yh = histcounts(yval , ybins);
        yh = yh/sum(yh);
        axyh{u}{ii} = axes('parent' , Findiv{u} , 'units' , 'inches' , 'position' , [allaxpos(ii,:) + [1.05 , 0] , 0.25 , 1] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'none' , 'linewidth' , 0.25 , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
            'TickDir' , 'out' , 'XLim' , [0 max(yh)] , 'XTick' , 1 , 'XTickLabel' , '');
        hold on;
        
        % so that no ink is shown when histcount == 0;
%         iBar = find(yh > 0);
%         for ib = 1 : length(iBar)
%             iib = iBar(ib);
%             bar(axyh{u}{ii} ,   ybins(iib) , yh(iib), 1 , 'horizontal' , 'on' , 'facecolor' , 'k' , 'linestyle' , 'none')
%         end
        bar(axyh{u}{ii} ,   ybins(1:end-1) , yh , 1 , 'horizontal' , 'on' , 'facecolor' , useCols{u} , 'linestyle' , 'none');
        ymaxI{u}(ii) = max(yval);
        end
        
        ymax(u) = max(cellfun(@(z) z.YLim(2) , axI{u}));
        xmax(u) = max(cellfun(@(z) z.XLim(2) , axI{u}));
       
    end
    ymax = max(ymax);
    xmax = max(xmax);
    for u = 1 : length(ug)
        
        for i = 1:length(axI{u})
            axI{u}{i}.YLim = [0 , ymax];
            axI{u}{i}.XLim = [0 , xmax];
            axyh{u}{i}.Position(4) = ymaxI{u}(i)/ymax;
            axyh{u}{i}.YLim = [0 , ymaxI{u}(i)];
        end
    end
    
end




if ~isempty(strfind(behavior , 'ocial'))
    iSocial = cellfun(@(z) ~isempty(strfind(z , 'ocial')) , behavList);
    for u = 1 : length(ug)
        i = find(cellfun(@(z) strcmp(z , ug{u}) , grpList) & iSocial);
        latency{u} = [];
        for ii = 1 : length(i)
            
            % convert epochs to not cross over minute marks so will be easy to
            tSt = [];
            tEnd = [];
            tVal = [];
            st = cohortData(i(ii)).starts;
            ed = cohortData(i(ii)).ends;
            val = cohortData(i(ii)).val; %cell2mat(cellfun(@(z) str2num(z) , cohortData(i(ii)).val , 'uniformoutput' , false));
            
            sI = find(cell2mat(cellfun(@(z) strcmp(z , 'Social') , cohortData(i(ii)).Legend , 'uniformoutput' , false)));
            latency{u}(end+1) = st(find(val == sI , 1));
            
            t = ed - st;
            socDur{u}{ii} = t(val == sI);
            
            for t = 1 : size(st , 1)
                range = [st(t)/60 , ceil(st(t)/60) : ceil(ed(t)/60)];
                if length(range) > 2
                    range(end) = ed(t)/60;
                    for r = 1 : length(range) - 1
                        tSt(end+1) = range(r) * 60;
                        tEnd(end+1) = range(r+1) * 60;
                        tVal(end+1) = val(t);
                    end
                else
                    tSt(end+1) = st(t);
                    tEnd(end+1) = ed(t);
                    tVal(end+1) = val(t);
                end
            end
            uv = unique(tVal)
            for uuv = 1 : length(uv)
                for hh = 1 : 5
                    iii = tVal == uv(uuv) & tSt/60 >= hh - 1 & tEnd/60 <= hh;
                    hMin{u}{uuv}(ii,hh) = sum(tEnd(iii) - tSt(iii));
                end
            end
        end
    end
    
    % Plot group data
    F = figure('units' , 'inches' , 'Position' , [0.5, 0.5 , 10 , 9]);
    fn = cohortData(1).Legend;
    ymax= [];
    
    ax.prefMnMn = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 5 1 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.25 length(ug) + 0.5] , 'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
    hold on;
    ax.prefMnMn.YLabel.String = ['Social Preference'];
    
    ax.prefMnMnCd = axes('parent' ,  F , 'units' , 'inches' , 'position' , [2 5 1.5 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0 1] , 'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'XTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
    hold on;
    ax.prefMnMnCd.YLabel.String = ['Cumulative Fraction'];
    ax.prefMnMnCd.XLabel.String = ['Social Preference'];
    
    for u = 1 : length(ug)
        
        d = mean(hMin{u}{1}' ./ (hMin{u}{1}' + hMin{u}{2}') , 1);
        sd = sort(d , 'ascend');
        jit = (rand([1 , length(d)]) - 0.5)/2;
        plot(ax.prefMnMn , repmat(u,1,length(d))+ jit , d , 'marker' , 'o' , 'markersize' , 3 , 'linestyle' , 'none' , 'markeredgecolor' , useCols{u} , 'markerfacecolor' , useCols{u});
        bar(ax.prefMnMn , u , mean(d) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 1);
        
        plot(ax.prefMnMnCd , [0 , sd(1)] , [0 , 1/length(d)] , 'linestyle' , ':' , 'linewidth' , 1 , 'marker' , 'none' , 'color' , useCols{u});
        plot(ax.prefMnMnCd , sd , [1:length(d)]/length(d) , 'linestyle' , '-' , 'linewidth' , 1.25 , 'marker' , 'none' , 'color' , useCols{u});
    end
    
    ax.total = axes('parent' ,  F , 'units' , 'inches' , 'position' , [4 5 1.5 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , 'Xlim' , [0.25 4] , 'ticklength' , [0 0]);
    hold on;
    ls = linspace(0.25 , 2.75 , length(ug)*2); d = diff(ls)/2;
    ls = ls + d(1);
    ax.total.XTick = ls;
    ax.total.XTick(end+1) = 3.5;
    xtl = repmat({'s' , 'e'},1,length(ug));
    xtl{end+1} = 'Total';
    ax.total.XTickLabel = xtl; clear xt;
    
    totTicks = linspace(3.25,3.75,length(ug)); dtot = diff(totTicks)/2;
    totTicks = totTicks + dtot(1);
    
    ax.total.YLabel.String = ['Interaction Time (s)'];
    
    for u = 1 : length(ug)
        
        ax.total.XTick([(u-1)*2 + 1 , (u-1)*2 + 2])
        for i = 1 : size(hMin{u}{1} , 1)
            p = [sum(hMin{u}{1}(i,:) , 2) , sum(hMin{u}{2}(i,:) , 2)];
            plot(ax.total , ax.total.XTick([(u-1)*2 + 1 , (u-1)*2 + 2]) , p , 'marker' , 'o' , 'markersize' , 3 , ...
                'color' , useCols{u} , 'markeredgecolor' , useCols{u} , 'markerfacecolor' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 1);
        end
        m1 = mean(sum(hMin{u}{1} , 2));
        m2 = mean(sum(hMin{u}{2} , 2));
        
        bar(ax.total , ax.total.XTick((u-1)*2 + 1) , m1 , 0.9*d(1)*2 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 1);
        bar(ax.total , ax.total.XTick((u-1)*2 + 2) , m2 , 0.9*d(1)*2 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 1);
        
        s = sum(hMin{u}{1} , 2) + sum(hMin{u}{2} , 2);
        jit = rand(1 , length(s))*dtot(1)/2;
        plot(ax.total , totTicks(u) + jit , s , 'linestyle' , 'none' , 'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        bar(ax.total , totTicks(u) , mean(s) , 0.8*dtot(1)*2 , 'facecolor' , 'none' , 'edgecolor' , useCols{u} , 'linestyle' , '-' , 'linewidth' , 0.75);
        %
    end
    
    
    ax.pref = axes('parent' ,  F , 'units' , 'inches' , 'position' , [5.5 0.5 2 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.5 5] , 'XTick' , [1:5]);
    hold on;
    ax.pref.XLabel.String = 'Minute';
    ax.pref.YLabel.String = ['Social Preference'];
    for u = 1 : length(ug)
        plot(ax.pref , repmat([1:5],size(hMin{u}{1},1),1)' , hMin{u}{1}' ./ (hMin{u}{1}' + hMin{u}{2}') , 'color' , useCols{u} , ...
            'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , useCols{u} , 'markerfacecolor' , useCols{u});
    end
    
    ax.prefMn = axes('parent' ,  F , 'units' , 'inches' , 'position' , [5.5 3 2 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.5 5] , 'XTick' , [1:5]);
    hold on;
    ax.prefMn.XLabel.String = 'Minute';
    ax.prefMn.YLabel.String = ['Social Preference'];
    for u = 1 : length(ug)
        d = hMin{u}{1};
        md = mean(d , 1);
        se = std(d , 1) / sqrt(size(d,1));
        prefd = hMin{u}{1} ./ (hMin{u}{1} + hMin{u}{2});
        mdp = mean(prefd , 1);
        sep = std(prefd , 1) / sqrt(size(prefd,1));
        plot(ax.prefMn , [1:5] , mdp , 'color' , useCols{u} , ...
            'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , useCols{u} , 'markeredgecolor' , useCols{u});
        for s = 1 : length(sep)
            plot(ax.prefMn  , [s , s] , [mdp(s) - sep(s) , mdp(s) + sep(s)] , 'color' , useCols{u} , ...
                'marker' , 'none' , 'linewidth' , 0.75 , 'linestyle' , '-');
        end
    end
    
    % Latency to first social interaction
    ax.latencyCd = axes('parent' ,  F , 'units' , 'inches' , 'position' , [6 5 1.5 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
    hold on;
    ax.latencyCd.YLabel.String = ['Cumulative Fraction'];
    ax.latencyCd.XLabel.String = ['Latency to Social Interaction (s)'];
    for u = 1 : length(ug)
        sd = sort(latency{u} , 'ascend');
        plot(ax.latencyCd , [0 sd(1)] , [0 , 1/length(sd)] , 'linestyle' , ':' , 'linewidth' , 1 , 'marker' , 'none' , 'color' , useCols{u});
        plot(ax.latencyCd , sd , [1:length(sd)]/length(sd) , 'linestyle' , '-' , 'linewidth' , 1.25 , 'marker' , 'none' , 'color' , useCols{u});
    end
    
    % Cumulative Distribution of individual social interaction times
    ax.socDurCd = axes('parent' ,  F , 'units' , 'inches' , 'position' , [8 5 1.5 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
    hold on;
    ax.socDurCd.YLabel.String = ['Cumulative Fraction'];
    ax.socDurCd.XLabel.String = ['Duration of Social Interaction (s)'];
    for u = 1 : length(ug)
        for i = 1 : length(socDur{u})
            sd = sort(socDur{u}{i} , 'ascend');
            plot(ax.socDurCd , [0 sd(1)] , [0 , 1/length(sd)] , 'linestyle' , ':' , 'linewidth' , 0.75 , 'marker' , 'none' , 'color' , useCols{u});
            plot(ax.socDurCd , sd , [1:length(sd)]/length(sd) , 'linestyle' , '-' , 'linewidth' , 0.75 , 'marker' , 'none' , 'color' , useCols{u});
            
        end
        
    end
    
    
    
    
    
    for f = 1 : length(fn)
        
        
        
        
        ax.ind.(fn{f}) = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 + 2.5*(f-1) 0.5 2 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
            'Xlim' , [0.5 5] , 'XTick' , [1:5]);
        hold on;
        ax.ind.(fn{f}).XLabel.String = 'Minute';
        ax.ind.(fn{f}).YLabel.String = ['Seconds in ' fn{f}];
        
        
        for u = 1 : length(ug)
            plot(ax.ind.(fn{f}) , repmat([1:5],size(hMin{u}{f},1),1)' , hMin{u}{f}' , 'color' , useCols{u} , ...
                'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , useCols{u} , 'markerfacecolor' , useCols{u});
        end
        ymax(f) = ax.ind.(fn{f}).YLim(2);
        
        ax.mn.(fn{f}) = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 + 2.5*(f-1) 3 2 1.5] , 'box' , 'off' , ...
            'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
            'Xlim' , [0.5 5] , 'XTick' , [1:5]);
        hold on;
        ax.mn.(fn{f}).XLabel.String = 'Minute';
        ax.mn.(fn{f}).YLabel.String = ['Seconds in ' fn{f}];
        
        
        
        for u = 1 : length(ug)
            d = hMin{u}{f};
            md = mean(d , 1);
            se = std(d , 1) / sqrt(size(d,1));
            %     prefd = hMin{u}{1} ./ (hMin{u}{1} + hMin{u}{2});
            %     mdp = mean(prefd , 1);
            %     sep = std(prefd , 1) / sqrt(size(prefd,1));
            plot(ax.mn.(fn{f}) , [1:5] , md , 'color' , useCols{u} , ...
                'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , useCols{u} , 'markerfacecolor' , useCols{u});
            for s = 1 : length(se)
                plot(ax.mn.(fn{f}) , [s , s] , [md(s) - se(s) , md(s) + se(s)] , 'color' , useCols{u} , ...
                    'marker' , 'none' , 'linewidth' , 0.75 , 'linestyle' , '-');
            end
        end
    end
    
    for f = 1 : length(fn)
        ax.ind.(fn{f}).YLim = [0 max(ymax)];
        ax.mn.(fn{f}).YLim = [0 max(ymax)];
    end
    
end


