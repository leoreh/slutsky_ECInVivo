function TL_analyzeBehavStruct(cohortData , type)

gen = {cohortData.Group};
ug = unique(gen);


if strcmp(type , 'fst')
    
    % need to do separately fst1 and fst2 and if both exist do a third
    % figure/column with the joint data
    
    
end


if strcmp(type , 'social')
for u = 1 : length(ug)
    i = find(cellfun(@(z) strcmp(z , ug{u}) , gen));
    latency{u} = [];
    for ii = 1 : length(i)
        
        % convert epochs to not cross over minute marks so will be easy to
        tSt = [];
        tEnd = [];
        tVal = [];
        st = cohortData(i(ii)).starts;
        ed = cohortData(i(ii)).ends;
        val = cohortData(i(ii)).val; %cell2mat(cellfun(@(z) str2num(z) , cohortData(i(ii)).val , 'uniformoutput' , false));
        
        sI = find(cell2mat(cellfun(@(z) strcmp(z , 'Social') , cohortData(i(ii)).Legend , 'uniformoutput' , false)));
        latency{u}(end+1) = st(find(val == sI , 1));
        
        t = ed - st;
        socDur{u}{ii} = t(val == sI);
        
        for t = 1 : size(st , 1)
            range = [st(t)/60 , ceil(st(t)/60) : ceil(ed(t)/60)];
            if length(range) > 2
                range(end) = ed(t)/60;
                for r = 1 : length(range) - 1
                    tSt(end+1) = range(r) * 60;
                    tEnd(end+1) = range(r+1) * 60;
                    tVal(end+1) = val(t);
                end
            else
                tSt(end+1) = st(t);
                tEnd(end+1) = ed(t);
                tVal(end+1) = val(t);
            end
        end
        uv = unique(tVal)
        for uuv = 1 : length(uv)
            for hh = 1 : 5
                iii = tVal == uv(uuv) & tSt/60 >= hh - 1 & tEnd/60 <= hh;
                hMin{u}{uuv}(ii,hh) = sum(tEnd(iii) - tSt(iii));
            end
        end
    end
end

cols = {'k' , 'c'};
% Plot group data
F = figure('units' , 'inches' , 'Position' , [0.5, 0.5 , 10 , 9]);
fn = cohortData(1).Legend;
ymax= [];

ax.prefMnMn = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 5 1 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'none' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.25 2.5] , 'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
ax.prefMnMn.YLabel.String = ['Social Preference'];

ax.prefMnMnCd = axes('parent' ,  F , 'units' , 'inches' , 'position' , [2 5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0 1] , 'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'XTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
ax.prefMnMnCd.YLabel.String = ['Cumulative Fraction'];
ax.prefMnMnCd.XLabel.String = ['Social Preference'];

for u = 1 : length(ug)
    
    d = mean(hMin{u}{1}' ./ (hMin{u}{1}' + hMin{u}{2}') , 1);
    sd = sort(d , 'ascend');
    jit = (rand([1 , length(d)]) - 0.5)/2;
    plot(ax.prefMnMn , repmat(u,1,length(d))+ jit , d , 'marker' , 'o' , 'markersize' , 3 , 'linestyle' , 'none' , 'markeredgecolor' , cols{u} , 'markerfacecolor' , cols{u});
    bar(ax.prefMnMn , u , mean(d) , 0.9 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1);
    
    plot(ax.prefMnMnCd , [0 , sd(1)] , [0 , 1/length(d)] , 'linestyle' , ':' , 'linewidth' , 1 , 'marker' , 'none' , 'color' , cols{u});
    plot(ax.prefMnMnCd , sd , [1:length(d)]/length(d) , 'linestyle' , '-' , 'linewidth' , 1.25 , 'marker' , 'none' , 'color' , cols{u});
end

ax.total = axes('parent' ,  F , 'units' , 'inches' , 'position' , [4 5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.25 4] , 'XTick' , [0.75 , 1.25 , 1.75 , 2.25 , 3.5] , ...
    'XTickLabelRotation' , 30 , 'XTickLabel' , {'Social' , 'Empty' , 'Social' , 'Empty' , 'Total'} , 'TickLength' , [0 0]);
hold on;
ax.total.YLabel.String = ['Interaction Time (s)'];

for u = 1 : length(ug)
    
    for i = 1 : size(hMin{u}{1} , 1)
        p = [sum(hMin{u}{1}(i,:) , 2) , sum(hMin{u}{2}(i,:) , 2)];
        plot(ax.total , [u - 0.25 , u + 0.25] , p , 'marker' , 'o' , 'markersize' , 3 , ...
            'color' , cols{u} , 'markeredgecolor' , cols{u} , 'markerfacecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1);
    end
    m1 = mean(sum(hMin{u}{1} , 2));
    m2 = mean(sum(hMin{u}{2} , 2));
    
    bar(ax.total , u - 0.25 , m1 , 0.45 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.125);
    bar(ax.total , u + 0.25 , m2 , 0.45 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.125);
    
    s = sum(hMin{u}{1} , 2) + sum(hMin{u}{2} , 2);
    jit = (rand([1 , length(s)]) - 0.125)/4;
    plot(ax.total , 3.25 + 0.5*(u-1) + jit , s , 'linestyle' , 'none' , 'marker' , 'o' , 'markersize' , 3 , 'markerfacecolor' , cols{u} , 'markeredgecolor' , cols{u});
    bar(ax.total , 3.25 + 0.5*(u-1) , mean(s) , 0.45 , 'facecolor' , 'none' , 'edgecolor' , cols{u} , 'linestyle' , '-' , 'linewidth' , 1.125);
    
end


ax.pref = axes('parent' ,  F , 'units' , 'inches' , 'position' , [5.5 0.5 2 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.5 5] , 'XTick' , [1:5]);
hold on;
ax.pref.XLabel.String = 'Minute';
ax.pref.YLabel.String = ['Social Preference'];
for u = 1 : length(ug)
    plot(ax.pref , repmat([1:5],size(hMin{u}{1},1),1)' , hMin{u}{1}' ./ (hMin{u}{1}' + hMin{u}{2}') , 'color' , cols{u} , ...
        'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , cols{u} , 'markerfacecolor' , cols{u});
end

ax.prefMn = axes('parent' ,  F , 'units' , 'inches' , 'position' , [5.5 3 2 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'Xlim' , [0.5 5] , 'XTick' , [1:5]);
hold on;
ax.prefMn.XLabel.String = 'Minute';
ax.prefMn.YLabel.String = ['Social Preference'];
for u = 1 : length(ug)
    d = hMin{u}{1};
    md = mean(d , 1);
    se = std(d , 1) / sqrt(size(d,1));
    prefd = hMin{u}{1} ./ (hMin{u}{1} + hMin{u}{2});
    mdp = mean(prefd , 1);
    sep = std(prefd , 1) / sqrt(size(prefd,1));
    plot(ax.prefMn , [1:5] , mdp , 'color' , cols{u} , ...
        'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , cols{u} , 'markeredgecolor' , cols{u});
    for s = 1 : length(sep)
        plot(ax.prefMn  , [s , s] , [mdp(s) - sep(s) , mdp(s) + sep(s)] , 'color' , cols{u} , ...
            'marker' , 'none' , 'linewidth' , 0.75 , 'linestyle' , '-');
    end
end

% Latency to first social interaction
ax.latencyCd = axes('parent' ,  F , 'units' , 'inches' , 'position' , [6 5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
ax.latencyCd.YLabel.String = ['Cumulative Fraction'];
ax.latencyCd.XLabel.String = ['Latency to Social Interaction (s)'];
for u = 1 : length(ug)
    sd = sort(latency{u} , 'ascend');
    plot(ax.latencyCd , [0 sd(1)] , [0 , 1/length(sd)] , 'linestyle' , ':' , 'linewidth' , 1 , 'marker' , 'none' , 'color' , cols{u});
    plot(ax.latencyCd , sd , [1:length(sd)]/length(sd) , 'linestyle' , '-' , 'linewidth' , 1.25 , 'marker' , 'none' , 'color' , cols{u});
end

% Cumulative Distribution of individual social interaction times
ax.socDurCd = axes('parent' ,  F , 'units' , 'inches' , 'position' , [8 5 1.5 1.5] , 'box' , 'off' , ...
    'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
    'YLim' , [0 1] , 'YTick' , [0 : 0.25 : 1] , 'TickLength' , [0 0]);
hold on;
ax.socDurCd.YLabel.String = ['Cumulative Fraction'];
ax.socDurCd.XLabel.String = ['Duration of Social Interaction (s)'];
for u = 1 : length(ug)
  for i = 1 : length(socDur{u})
      sd = sort(socDur{u}{i} , 'ascend');
          plot(ax.socDurCd , [0 sd(1)] , [0 , 1/length(sd)] , 'linestyle' , ':' , 'linewidth' , 0.75 , 'marker' , 'none' , 'color' , cols{u});
    plot(ax.socDurCd , sd , [1:length(sd)]/length(sd) , 'linestyle' , '-' , 'linewidth' , 0.75 , 'marker' , 'none' , 'color' , cols{u});
      
  end
  
end





for f = 1 : length(fn)
    
    
    
    
    ax.ind.(fn{f}) = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 + 2.5*(f-1) 0.5 2 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.5 5] , 'XTick' , [1:5]);
    hold on;
    ax.ind.(fn{f}).XLabel.String = 'Minute';
    ax.ind.(fn{f}).YLabel.String = ['Seconds in ' fn{f}];
    
    
    for u = 1 : length(ug)
        plot(ax.ind.(fn{f}) , repmat([1:5],size(hMin{u}{f},1),1)' , hMin{u}{f}' , 'color' , cols{u} , ...
            'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , cols{u} , 'markerfacecolor' , cols{u});
    end
    ymax(f) = ax.ind.(fn{f}).YLim(2);
    
    ax.mn.(fn{f}) = axes('parent' ,  F , 'units' , 'inches' , 'position' , [0.5 + 2.5*(f-1) 3 2 1.5] , 'box' , 'off' , ...
        'color' , 'none' , 'YColor' , 'k' , 'XColor' , 'k' , 'fontname' , 'arial' , 'fontsize' , 8 , ...
        'Xlim' , [0.5 5] , 'XTick' , [1:5]);
    hold on;
    ax.mn.(fn{f}).XLabel.String = 'Minute';
    ax.mn.(fn{f}).YLabel.String = ['Seconds in ' fn{f}];
    
    
    
    for u = 1 : length(ug)
        d = hMin{u}{f};
        md = mean(d , 1);
        se = std(d , 1) / sqrt(size(d,1));
        %     prefd = hMin{u}{1} ./ (hMin{u}{1} + hMin{u}{2});
        %     mdp = mean(prefd , 1);
        %     sep = std(prefd , 1) / sqrt(size(prefd,1));
        plot(ax.mn.(fn{f}) , [1:5] , md , 'color' , cols{u} , ...
            'marker' , 'o' , 'markersize' , 3 , 'linewidth' , 1 , 'linestyle' , '-' , 'markeredgecolor' , cols{u} , 'markerfacecolor' , cols{u});
        for s = 1 : length(se)
            plot(ax.mn.(fn{f}) , [s , s] , [md(s) - se(s) , md(s) + se(s)] , 'color' , cols{u} , ...
                'marker' , 'none' , 'linewidth' , 0.75 , 'linestyle' , '-');
        end
    end
end

for f = 1 : length(fn)
    ax.ind.(fn{f}).YLim = [0 max(ymax)];
    ax.mn.(fn{f}).YLim = [0 max(ymax)];
end

end


