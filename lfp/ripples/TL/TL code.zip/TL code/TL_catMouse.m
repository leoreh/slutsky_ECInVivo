function [cat] = TL_catMouse(pathname , saveCat)

% Concatenates data from each day of recording for a given mouse, places in
% folder named "cat" . Must be run after TL_spikeWrapper & TL_rippleWrapper

% Concatenate multiunit spikes from the ripple tetrode from each day
% " ripples
% " sleep states
% " single unit spikes

% Add time of day
% Add light phase
% Add day #
% Add manipulation

%% Make some variables

% [stateList] : List of states that will refer to each corresponding value in states (eg.
% 1 = activeWake, 2 = quietWake...)
stateList = {'activeWake', 'quietWake' , 'lightSleep' , 'NREM' , 'REM' , 'bin' , 'unknown'};

% [statecols] : Color code for each state in stateList
stateCols = [0.8 0 0; 1 0.25 0.25; 0.25 0.25 0.8; 0 0 0.8; 0.25 0.8 0.25; 0.4 0.4 0.4; 0.7 0.7 0.7];

%% Find list of folders representing each recording date

% [recDates] : cell array list of recording dates for this mouse
% -------------------------------------------------------------------------
if ~strcmp(pathname(end) , filesep)
    pathname = [pathname , filesep];
end

fn = dir(pathname);
fn = {fn.name};
i = cell2mat(cellfun(@(z) isempty(strfind(z , '.')) , fn , 'uniformoutput' , false));
recDates = [fn(i)];
clear i fn;

cat.mu.spt = [];
cat.mu.recNum = [];
cat.su.spt = [];
cat.su.recNum = [];
cat.su.tet = [];
cat.su.clusID = [];
cat.su.spkWidth = [];
cat.state.val = [];
cat.state.sec = [];
cat.ripples.recNum = [];
cat.gap = [];

offsetSec = 0;
offsetI = 0;
for r = 1 : length(recDates)
    
    %% Load data from this recording date
    
    % [ripples] : ripple structure outputted from TL_rippleWrapper --------
    temp = dir([pathname , recDates{r} , filesep , '*ripples*']);
    load([pathname , recDates{r} , filesep  , temp.name]);
    clear temp;
    if r == 1
        fn = fieldnames(ripples.detect);
        for f = 1 : length(fn)
            cat.ripples.(fn{f}) = [];
        end
        cat.ripples.peakSec = []; % for later
        cat.ripples.rangeSec = []; % for later;
        
        startHr = ripples.expInfo.RecStartTime;
        lightsHr = ripples.expInfo.LightsTime;
    end
    % ---------------------------------------------------------------------
    
    % [mu] : multiunit spike times from the ripple channel in seconds -----
    temp = dir([pathname , recDates{r} , filesep ,  '*spktimes*']);
    load([pathname , recDates{r} , filesep  , temp.name]);
    mu = spktimes{ripples.expInfo.ripChan};
    % some mu spike files refaela sent were as integer indices..others as
    % time..so check format and convert to seconds if necessary
    if r == 4
    end
    if sum(~rem(mu,1)) == length(mu)
        mu = mu/ripples.expInfo.rawSampRate;
    end
    clear spktimes temp;
    
    % [SleepState] : sleep structure outputted from sleep scoring or sth..
    temp = dir([pathname , recDates{r} , filesep ,  '*SleepState.states*']);
    
    % refaela did not give all same sleepstate structure formats per day so
    % need to parse this out...
    if ~isempty(temp) % If she gave the 'SleepState' structure..
        temp = load([pathname , recDates{r} , filesep  , temp.name]);
        SleepState = temp.SleepState;
        clear temp
        % Standardize sleep state values to stateList variable
        % Alter state names (Not all states may have been included, and they may
        % have been entered with a different name)
        og = SleepState.idx.statenames;
        i = find(strcmp(og, 'WAKE'));
        if ~isempty(i)
            og{i} = 'activeWake';
        end
        [uS , uI] = unique(og);
        i = cell2mat(cellfun(@(z) ~isempty(z) , uS , 'uniformoutput' , false));
        uS = uS(i);
        uI = uI(i);
        for u = 1 : length(uS)
            newVal = find(strcmp(stateList , uS{u}));
            SleepState.idx.states(SleepState.idx.states == uI(u)) = newVal;
            %     data.ripList.states([data.ripList.states == uI(u)]) = newVal;
        end
        clear og i uS uI i uS uI u newVal;
        
    else % if she gave the 'SleepStateEpisodes' instead of SleepState'...
        % make 'SleepState.idx.states'
        clear SleepState;
        temp = dir([pathname , recDates{r} , filesep ,  '*SleepStateEpisodes.states*']);
        load([pathname , recDates{r} , filesep  , temp.name]);
        
        fn = fieldnames(SleepStateEpisodes.ints);
        i = cellfun(@(z) strfind(z , 'episode'), fn , 'uniformoutput',false);
        i = ~cellfun(@isempty , i);
        fn = [fn(i)];
        for f = 1 : length(fn)
            d = SleepStateEpisodes.ints.(fn{f});
            if strfind(fn{f},'WAKE')
                val = 1;
            end
            if strfind(fn{f},'NREM')
                val = 4;
            end
            if strfind(fn{f},'REM') == 1
                val = 5;
            end
            for dd = 1 : size(d,1)
                SleepState.idx.states([d(dd,1):d(dd,2)]) = val;
            end
             SleepState.idx.states =  SleepState.idx.states';
        end
    end
    % ---------------------------------------------------------------------
    
    % [su] : cell array, each cell is a single unit and its corresponding spike
    % times in seconds ----------------------------------------------------
    temp = dir([pathname , recDates{r} , filesep ,  '*spikes.cell*']);
    load([pathname , recDates{r} , filesep  , temp.name]);
    su = spikes.times;
    
    %% Calculate offset for the current recording
    %     L =  TL_getLFP('basepath' , [pathname , recDates{r} , filesep] , 'ch' , 1 , 'fs' , 1250 , ...
    %         'extension' , 'lfp' , 'savevar' , true , 'forceL' , true);
    %     sec = L.timestamps(end) + 1/1250;
    %     indx = length(L.data);
    %     offsetSec(r+1) = sum(offsetSec(1:r)) + sec + 1/1250
    %     offsetI(r+1) = sum(offsetI(1:r)) + indx;
    %     clear L sec indx;
    
    % Instead calculate it based on the excel spreadsheets
    offsetSec(r) =  60*60*((r-1)*24 - (startHr - ripples.expInfo.RecStartTime));
    offsetI(r) = offsetSec(r) * 1250;
    
    %% Begin merging
    % Merge multi-unit spikes
    
    cat.mu.spt = [cat.mu.spt; mu + offsetSec(r)];
    cat.mu.recNum = [cat.mu.recNum; r * ones(length(mu) , 1)];
    
    % Merge single-unit data
    % add offset to all sorted units before concatenating
    temp = cellfun(@(z) z + offsetSec(r) , su , 'uniformoutput' , false)';
    cat.su.spt = [cat.su.spt; temp];
    cat.su.recNum = [cat.su.recNum; r * ones(length(su) , 1)];
    cat.su.tet = [cat.su.tet; spikes.shankID'];
    cat.su.clusID = [cat.su.clusID; spikes.cluID'];
    % calculate spike width of each unit
    spkWidth = nan(length(spikes.cluID),1);
    for s = 1 : length(spikes.cluID)
        % different fieldnames for different recordings from refaela's set
        % so...
        try
            wave = spikes.rawWaveform_all{s}(spikes.maxWaveformCh1(s),:);
        catch
            
            wave = spikes.rawWaveform{s};%(spikes.maxWaveformCh(s)+1,:);
        end
        [~ , trough] = min(wave);
        [~ , pk] = max(wave(trough : end));
        pk = pk + trough;
        spkWidth(s) = 1000 * (pk - trough) / ripples.expInfo.rawSampRate;
    end
    cat.su.spkWidth = [cat.su.spkWidth; spkWidth];
    clear spkWidth wave trough pk;
    
    cat.expInfo{r} = ripples.expInfo;
    cat.expInfo{r}.offsetSec = offsetSec(r);
    % Merge ripple data
    %     % First add offsets
    %     ripples.detect.lfpIndx = ripples.detect.lfpIndx + offsetI(r);
    %     ripples.detect.peakPosition = (ripples.detect.peakPosition + offsetI(r))/ripples.expInfo.lfpSampRate; % peakPosition converted to time..
    ripples.detect.rangeSec = (ripples.detect.lfpIndx + offsetI(r))/ripples.expInfo.lfpSampRate;
    ripples.detect.peakSec = (ripples.detect.peakPosition + offsetI(r))/ripples.expInfo.lfpSampRate; % peakPosition converted to time..
    %     ripples.detect = rmfield(ripples.detect , 'lfpIndx');
    %     ripples.detect = rmfield(ripples.detect , 'peakPosition');
    %     if r == 1
    %         fn2 = fieldnames(ripples.detect);
    % %     end
    %     for f = 1 : length(fn2)
    %         cat.ripples.(fn2{f}) = [cat.ripples.(fn2{f}); ripples.detect.(fn2{f})];
    %     end
    %     end
    if r == 1
        fn2 = fieldnames(ripples.detect);
    end
    for f = 1 : length(fn2)
        cat.ripples.(fn2{f}) = [cat.ripples.(fn2{f}); ripples.detect.(fn2{f})];
    end
    
    cat.ripples.recNum = [cat.ripples.recNum; r * ones(size(ripples.detect.peakSec,1),1)];
    
    % merge sleep data
    cat.state.val = [cat.state.val; SleepState.idx.states];
    cat.state.sec = [cat.state.sec; [1:length(SleepState.idx.states)]'+offsetSec(r)];
    
    % Mark gap periods between recordings (eg times when no data is being
    % collected
    if r > 1
        gapT = offsetSec(r) - offsetSec(r-1) - cat.expInfo{r-1}.recLengthSec;
        cat.gap(size(cat.gap,1)+1,[1:2]) = [offsetSec(r) - gapT , offsetSec(r)];
        clear gapT;
    end
    
end

cat.ripples = rmfield(cat.ripples , 'lfpIndx');
cat.ripples = rmfield(cat.ripples , 'peakPosition');

%% Now add the time to the recording


%% Save the cat

if saveCat
    save([pathname , 'cat.mat'],'cat')
end

end